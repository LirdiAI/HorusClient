package com.horus.launcher;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.lang.management.ManagementFactory;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.security.MessageDigest;
import java.time.Duration;
import java.util.*;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import javax.imageio.ImageIO;

import com.sun.management.OperatingSystemMXBean;

public class HorusLauncher {

    static final String MC_VERSION = "1.21.4";
    static final String LOADER_VERSION = "0.16.14";
    static final String LOADER_VERSION_ID = "fabric-loader-" + LOADER_VERSION + "-" + MC_VERSION;
    static final String INSTALLER_VERSION = "1.1.2";
    static final String VERSION_MANIFEST = "https://launchermeta.mojang.com/mc/game/version_manifest_v2.json";
    static final String INSTALLER_URL = "https://maven.fabricmc.net/net/fabricmc/fabric-installer/" + INSTALLER_VERSION + "/fabric-installer-" + INSTALLER_VERSION + ".jar";
    static final String FABRIC_API_QUERY = "https://api.modrinth.com/v2/project/fabric-api/version?game_versions=%5B%221.21.4%22%5D&loaders=%5B%22fabric%22%5D";
    static final String MODRINTH_SEARCH = "https://api.modrinth.com/v2/search?query=";
    static final String MODRINTH_FACETS = "&facets=%5B%5B%22versions%3A1.21.4%22%5D%2C%5B%22project_type%3Amod%22%5D%5D";
    static final String MODRINTH_VERSIONS = "https://api.modrinth.com/v2/project/";
    static final String SITE_API = "https://horusclient-t7wn.onrender.com";
    static final String VERSION_HORUS = "Horus 1.21.4";
    static final String CLIENT_URL_HORUS = "https://github.com/LirdiAI/HorusClient/releases/download/LauncherDOwn/Horus-1.21-1.0.0.jar";
    static final String NEWS_TEXT = "Изменения клиента Horus 1.21.4: (1.2)\n"
            + "• Был обновлен AutoMace (Combat/AutoMace) - добавили много обходов и пробитие сквозь стену\n"
            + "• Добавили banbypass (Render/BanBypass) - обходит многие блокировки, с помощью фальшивых Ip-Адресов, "
            + "еще было добавлено вставление своих покупных прокси.";

    private static final int ICON_FOLDER = 1;
    private static final int ICON_LOGOUT = 2;
    private static final int ICON_PICTURE = 3;
    private static final int ICON_DOT = 4;
    private static final int ICON_OPEN = 5;

    private final Path appDir = locateAppDir();
    private final HttpClient http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(20)).followRedirects(HttpClient.Redirect.NORMAL).build();

    private JFrame frame;
    private MainPanel rootMain;
    private CardLayout cardsLayout;
    private JPanel cardsPanel;
    private CardLayout subLayout;
    private JPanel subCards;
    private JLabel titleLabel;
    private Map<String, TabButton> tabs = new LinkedHashMap<>();

    private JPanel toastPanel;
    private JLabel toastLabel;
    private javax.swing.Timer toastTimer;
    private JPanel dlPanel;
    private JLabel dlLabel;

    private JTextArea logArea;
    private GlowButton launchBtn;
    private GlowButton installBtn;
    private GlowButton openBtn;
    private JProgressBar progressBar;
    private JLabel statusLabel;
    private RamSlider ramSlider;
    private int ramGb = 4;
    private Path gameDir;

    private JTextField loginField;
    private JPasswordField passwordField;
    private GlowButton loginBtn;
    private JLabel authStatusLabel;
    private JLabel loginErrLabel;
    private JLabel pwErrLabel;
    private JLabel welcomeLabel;

    private JPanel addonsListPanel;
    private JTextField addonSearchField;

    private String accountLogin = "";
    private String accountUid = "";
    private String accountRole = "Пользователь";
    private String accountExpiry = "—";
    private String accountPlan = "";
    private boolean isLaunching = false;
    private long sessionStartedAt = 0;

    private static final Color BG_DARK = new Color(10, 14, 25);
    private static final Color BG_CARD = new Color(16, 22, 40);
    private static final Color INPUT_BG = new Color(24, 32, 54);
    private static final Color BTN = new Color(147, 74, 224);
    private static final Color BTN_HOVER = new Color(168, 85, 247);
    private static final Color ACCENT = new Color(216, 180, 254);
    private static final Color ACCENT2 = new Color(168, 85, 247);
    private static final Color TEXT = new Color(238, 240, 250);
    private static final Color TEXT_DIM = new Color(139, 144, 170);
    private static final Color BORDER = new Color(45, 55, 85);
    private static final Color SUCCESS = new Color(74, 222, 128);
    private static final Color DANGER = new Color(225, 29, 72);
    private static final Color WARN = new Color(245, 158, 11);
    private static final Color INFO = new Color(62, 195, 244);

    private static Path locateAppDir() {
        try {
            Path jarPath = Path.of(HorusLauncher.class.getProtectionDomain().getCodeSource().getLocation().toURI());
            return jarPath.getParent();
        } catch (Exception e) {
            return Path.of(".");
        }
    }

    public static void main(String[] args) {
        System.setProperty("sun.java2d.opengl", "true");
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception ignored) {
            }
            HorusLauncher launcher = new HorusLauncher();
            launcher.init();
        });
    }

    private void init() {
        gameDir = gameDirOrDef();
        accountUid = readLauncherConfig("uid");
        if (accountUid == null) accountUid = "";
        accountLogin = readLauncherConfig("username");
        if (accountLogin == null) accountLogin = "";
        String role = readLauncherConfig("role");
        if (role != null) accountRole = role;
        String plan = readLauncherConfig("plan");
        if (plan != null) accountPlan = plan;
        try { ramGb = Integer.parseInt(readLauncherConfig("ram")); } catch (Exception ignored) {}

        frame = new JFrame("HorusLauncher");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1050, 650);
        frame.setMinimumSize(new Dimension(900, 560));
        frame.setUndecorated(true);
        frame.setBackground(new Color(0, 0, 0, 0));

        rootMain = new MainPanel();
        frame.setContentPane(rootMain);
        buildUI();
        frame.setLocationRelativeTo(null);
        try {
            frame.setOpacity(0f);
            frame.setVisible(true);
            final long fadeStart = System.currentTimeMillis();
            javax.swing.Timer fadeIn = new javax.swing.Timer(16, ev -> {
                float fp = Math.min(1f, (System.currentTimeMillis() - fadeStart) / 300f);
                frame.setOpacity(fp * fp * (3f - 2f * fp));
                if (fp >= 1f) ((javax.swing.Timer) ev.getSource()).stop();
            });
            fadeIn.start();
        } catch (Exception ex) {
            frame.setOpacity(1f);
            frame.setVisible(true);
        }
        applySavedSession();
    }

    private void log(String msg) {
        try {
            Path logFile = appDir.resolve("launcher.log");
            Files.writeString(logFile, msg + System.lineSeparator(), StandardCharsets.UTF_8,
                    Files.exists(logFile) ? java.nio.file.StandardOpenOption.APPEND : java.nio.file.StandardOpenOption.CREATE);
        } catch (Exception ignored) {
        }
        SwingUtilities.invokeLater(() -> {
            try {
                if (logArea != null) {
                    logArea.append(msg + System.lineSeparator());
                    logArea.setCaretPosition(logArea.getDocument().getLength());
                }
                if (statusLabel != null) statusLabel.setText(msg.length() > 58 ? msg.substring(0, 55) + "..." : msg);
            } catch (Exception ignored) {
            }
        });
    }

    private void showToast(String message) {
        SwingUtilities.invokeLater(() -> {
            if (toastTimer != null) {
                toastTimer.stop();
                toastTimer = null;
            }
            toastLabel.setText(message);
            toastPanel.setVisible(true);
            toastPanel.revalidate();
            toastPanel.repaint();
            toastTimer = new javax.swing.Timer(3500, e -> {
                toastPanel.setVisible(false);
                ((javax.swing.Timer) e.getSource()).stop();
            });
            toastTimer.setRepeats(false);
            toastTimer.start();
        });
    }

    private void showDownload(String text) {
        SwingUtilities.invokeLater(() -> {
            dlLabel.setText(text);
            dlPanel.setVisible(true);
        });
    }

    private void hideDownload() {
        SwingUtilities.invokeLater(() -> dlPanel.setVisible(false));
    }

    private static int totalRamGb() {
        long bytes;
        try {
            bytes = ((OperatingSystemMXBean) ManagementFactory.getOperatingSystemMXBean()).getTotalPhysicalMemorySize();
        } catch (Throwable t) {
            bytes = Runtime.getRuntime().maxMemory();
        }
        if (bytes <= 0) bytes = Runtime.getRuntime().maxMemory();
        return (int) Math.max(4, Math.min(64, bytes / (1024L * 1024 * 1024)));
    }

    /* ═══════════════════════════════════════════════════════════════
       MAIN PANEL — фон, частицы, перетаскивание окна
       ═══════════════════════════════════════════════════════════════ */
    class MainPanel extends JPanel {
        private Point dragOffset;
        private final List<Particle> particles = new ArrayList<>();
        private float gradientPhase = 0f;
        private final float[] blobPhase = {0f, 2.1f, 4.2f};
        private BufferedImage bgImage;

        MainPanel() {
            setLayout(new BorderLayout(0, 0));
            setOpaque(false);
            initParticles();
            loadBg();

            javax.swing.Timer animTimer = new javax.swing.Timer(33, e -> {
                gradientPhase += 0.008f;
                for (int i = 0; i < blobPhase.length; i++) blobPhase[i] += 0.006f;
                for (Particle p : particles) p.update();
                repaint();
            });
            animTimer.start();

            addMouseListener(new MouseAdapter() {
                public void mousePressed(MouseEvent e) {
                    dragOffset = e.getPoint();
                }
            });
            addMouseMotionListener(new MouseMotionAdapter() {
                public void mouseDragged(MouseEvent e) {
                    frame.setLocation(e.getLocationOnScreen().x - dragOffset.x, e.getLocationOnScreen().y - dragOffset.y);
                }
            });
        }

        void reloadBg() {
            bgImage = null;
            loadBg();
            repaint();
        }

        private void loadBg() {
            String bgPath = readLauncherConfig("bg_path");
            if (bgPath != null && !bgPath.isEmpty()) {
                try {
                    bgImage = ImageIO.read(new File(bgPath));
                } catch (Exception ignored) {
                }
            }
        }

        private void initParticles() {
            for (int i = 0; i < 55; i++) particles.add(new Particle(getWidth(), getHeight()));
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            int w = getWidth(), h = getHeight();

            GradientPaint bg = new GradientPaint(0, 0, BG_DARK, 0, h, new Color(7, 10, 18));
            g2.setPaint(bg);
            g2.fillRoundRect(0, 0, w, h, 18, 18);

            if (bgImage != null) {
                float scale = Math.max(w / (float) bgImage.getWidth(), h / (float) bgImage.getHeight());
                int iw = (int) (bgImage.getWidth() * scale), ih = (int) (bgImage.getHeight() * scale);
                int ix = (w - iw) / 2, iy = (h - ih) / 2;
                g2.drawImage(bgImage, ix, iy, iw, ih, null);
            }

            float phase = (float) (Math.sin(gradientPhase) * 0.5 + 0.5);
            Color glowA = new Color(147, 74, 224, 40);
            Color glowB = new Color(168, 85, 247, 34);
            RadialGradientPaint rgp = new RadialGradientPaint(
                    w * 0.72f, h * 0.28f, w * 0.62f,
                    new float[]{0f, 0.5f, 1f},
                    new Color[]{lerpColor(glowA, glowB, phase), lerpColor(glowB, glowA, phase), new Color(0, 0, 0, 0)}
            );
            g2.setPaint(rgp);
            g2.fillRect(0, 0, w, h);

            drawBlobs(g2, w, h);

            g2.setColor(new Color(255, 255, 255, 6));
            g2.setStroke(new BasicStroke(1f));
            for (int gx = 0; gx <= w; gx += 56) {
                g2.drawLine(gx, 0, gx, h);
            }
            for (int gy = 0; gy <= h; gy += 56) {
                g2.drawLine(0, gy, w, gy);
            }

            for (int pi = 0; pi < particles.size(); pi++) {
                Particle p = particles.get(pi);
                float alpha = (float) (Math.sin(p.life) * 0.4 + 0.5);
                Color pb = (pi % 3 == 0) ? INFO : ACCENT2;
                g2.setColor(new Color(pb.getRed(), pb.getGreen(), pb.getBlue(), (int) (alpha * 90)));
                g2.fillOval((int) p.x, (int) p.y, p.size, p.size);
            }

            g2.setColor(new Color(ACCENT.getRed(), ACCENT.getGreen(), ACCENT.getBlue(), 50));
            g2.setStroke(new BasicStroke(1f));
            g2.drawRoundRect(0, 0, w - 1, h - 1, 18, 18);

            g2.dispose();
        }

        private void drawBlobs(Graphics2D g2, int w, int h) {
            float[][] blobs = {
                    {0.10f, 0.08f, 260f, 0f, 0f, 0.7f, 1f},
                    {0.88f, 0.30f, 230f, 62f, 195f, 0.7f, 0.9f},
                    {0.34f, 0.88f, 210f, 168f, 85f, 0.8f, 0.6f}
            };
            for (int i = 0; i < blobs.length; i++) {
                float[] b = blobs[i];
                float fx = b[0], fy = b[1];
                float radius = b[2];
                float pr = 168, pg = 85, pb = 247;
                if (b[3] != 0f) { pr = b[3]; pg = b[4]; pb = 247f; }
                float dx = (float) Math.sin(blobPhase[i]) * (b[5] * radius * 0.35f);
                float dy = (float) Math.cos(blobPhase[i] * 0.9f) * (b[6] * radius * 0.3f);
                float cx = fx * w + dx;
                float cy = fy * h + dy;
                Color center = new Color((int) pr, (int) pg, (int) pb, 90);
                RadialGradientPaint gp = new RadialGradientPaint(
                        cx, cy, radius,
                        new float[]{0f, 1f},
                        new Color[]{center, new Color((int) pr, (int) pg, (int) pb, 0)});
                g2.setPaint(gp);
                g2.fillOval((int) (cx - radius), (int) (cy - radius), (int) radius * 2, (int) radius * 2);
            }
        }

        private Color lerpColor(Color a, Color b, float t) {
            return new Color(
                    (int) (a.getRed() + (b.getRed() - a.getRed()) * t),
                    (int) (a.getGreen() + (b.getGreen() - a.getGreen()) * t),
                    (int) (a.getBlue() + (b.getBlue() - a.getBlue()) * t),
                    (int) (a.getAlpha() + (b.getAlpha() - a.getAlpha()) * t)
            );
        }
    }

    /* ═══════════════════════════════════════════════════════════════
       BUILD UI — общая рамка: title bar + cards (login | main)
       ═══════════════════════════════════════════════════════════════ */
    private void buildUI() {
        JPanel titleBar = buildTitleBar();
        rootMain.add(titleBar, BorderLayout.NORTH);

        cardsLayout = new CardLayout();
        cardsPanel = new JPanel(cardsLayout);
        cardsPanel.setOpaque(false);
        cardsPanel.add(buildLoginScreen(), "login");
        cardsPanel.add(buildMainScreen(), "main");
        rootMain.add(cardsPanel, BorderLayout.CENTER);

        makeOverlays();
        cardsLayout.show(cardsPanel, "login");
        titleLabel.setText("Вход");
        if (welcomeLabel != null) welcomeLabel.setText(" ");
        showView("home");
    }

    private JPanel buildTitleBar() {
        JPanel bar = new JPanel(new BorderLayout());
        bar.setOpaque(false);
        bar.setPreferredSize(new Dimension(0, 48));
        bar.setBorder(BorderFactory.createEmptyBorder(8, 24, 8, 14));

        JPanel left = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        left.setOpaque(false);
        JLabel icon = new JLabel(iconDotPulse(ACCENT));
        left.add(icon);
        titleLabel = new JLabel("Вход");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 15));
        titleLabel.setForeground(TEXT);
        left.add(titleLabel);
        bar.add(left, BorderLayout.WEST);

        JPanel btns = new JPanel(new FlowLayout(FlowLayout.RIGHT, 6, 0));
        btns.setOpaque(false);
        CircleButton minBtn = new CircleButton("-", TEXT_DIM);
        CircleButton closeBtn = new CircleButton("x", DANGER);
        minBtn.addActionListener(() -> frame.setState(Frame.ICONIFIED));
        closeBtn.addActionListener(() -> System.exit(0));
        btns.add(minBtn);
        btns.add(closeBtn);
        bar.add(btns, BorderLayout.EAST);
        return bar;
    }

    private void makeOverlays() {
        dlPanel = new RoundedPanel(BG_CARD, 16);
        dlPanel.setLayout(new BorderLayout(8, 0));
        dlLabel = new JLabel(" ");
        dlLabel.setFont(new Font("Segoe UI", Font.BOLD, 12));
        dlLabel.setForeground(ACCENT);
        dlPanel.add(dlLabel, BorderLayout.CENTER);
        dlPanel.setBorder(BorderFactory.createCompoundBorder(
                new LineBorder(BORDER, 1, true), new EmptyBorder(9, 16, 9, 16)));
        dlPanel.setVisible(false);

        toastPanel = new RoundedPanel(BG_CARD, 16);
        toastLabel = new JLabel(" ");
        toastLabel.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        toastLabel.setForeground(Color.WHITE);
        toastPanel.add(toastLabel);
        toastPanel.setBorder(BorderFactory.createCompoundBorder(
                new LineBorder(ACCENT, 1, true), new EmptyBorder(8, 14, 8, 14)));
        toastPanel.setVisible(false);

        JLayeredPane lp = frame.getLayeredPane();
        lp.add(dlPanel, JLayeredPane.POPUP_LAYER);
        lp.add(toastPanel, JLayeredPane.POPUP_LAYER);
        frame.addComponentListener(new ComponentAdapter() {
            public void componentResized(ComponentEvent e) {
                layoutOverlays();
            }

            public void componentMoved(ComponentEvent e) {
                layoutOverlays();
            }
        });
        layoutOverlays();
    }

    private void layoutOverlays() {
        Dimension f = frame.getSize();
        dlPanel.setSize(380, 44);
        dlPanel.setLocation(f.width - 400, f.height - 58);
        toastPanel.setSize(320, 42);
        toastPanel.setLocation((f.width - 320) / 2, 54);
    }

    private JPanel buildMainScreen() {
        JPanel main = new JPanel(new BorderLayout(0, 0));
        main.setOpaque(false);

        JPanel sidebar = new JPanel();
        sidebar.setOpaque(false);
        sidebar.setPreferredSize(new Dimension(216, 0));
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setBorder(BorderFactory.createEmptyBorder(14, 14, 16, 10));

        JLabel logo = new GradientLabel("HorusLauncher");
        logo.setFont(new Font("Segoe UI", Font.BOLD, 17));
        logo.setAlignmentX(Component.LEFT_ALIGNMENT);
        sidebar.add(logo);
        sidebar.add(Box.createRigidArea(new Dimension(0, 2)));
        JLabel ver = new JLabel("1.21.4 · Fabric");
        ver.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        ver.setForeground(TEXT_DIM);
        ver.setAlignmentX(Component.LEFT_ALIGNMENT);
        sidebar.add(ver);
        sidebar.add(Box.createRigidArea(new Dimension(0, 22)));

        String[][] nav = {
                {"Главная", "home"},
                {"Профиль", "profile"},
                {"Новости", "news"},
                {"Настройки", "settings"},
                {"Дополнения", "addons"},
                {"Скриншоты", "screenshots"}
        };
        for (String[] item : nav) {
            TabButton tb = new TabButton(item[0]);
            tb.setOnClick(() -> showView(item[1]));
            tb.setAlignmentX(Component.LEFT_ALIGNMENT);
            tb.setMaximumSize(new Dimension(196, 40));
            sidebar.add(tb);
            sidebar.add(Box.createRigidArea(new Dimension(0, 4)));
            tabs.put(item[1], tb);
        }

        sidebar.add(Box.createVerticalGlue());

        JPanel accountBox = new JPanel();
        accountBox.setOpaque(false);
        accountBox.setLayout(new BoxLayout(accountBox, BoxLayout.Y_AXIS));
        accountBox.setAlignmentX(Component.LEFT_ALIGNMENT);
        accountBox.setMaximumSize(new Dimension(196, 92));
        accountBox.setBorder(BorderFactory.createCompoundBorder(
                new LineBorder(BORDER, 1, true),
                BorderFactory.createEmptyBorder(8, 10, 8, 10)));

        JPanel userWrap = new JPanel(new BorderLayout(6, 0));
        userWrap.setOpaque(false);
        userWrap.setAlignmentX(Component.LEFT_ALIGNMENT);
        userWrap.setMaximumSize(new Dimension(196, 30));
        welcomeLabel = new GradientLabel(" ");
        welcomeLabel.setFont(new Font("Segoe UI", Font.BOLD, 12));
        welcomeLabel.setForeground(ACCENT);
        userWrap.add(welcomeLabel, BorderLayout.CENTER);
        accountBox.add(userWrap);
        accountBox.add(Box.createRigidArea(new Dimension(0, 8)));

        JPanel buttonsRow = new JPanel(new FlowLayout(FlowLayout.CENTER, 6, 0));
        buttonsRow.setOpaque(false);
        buttonsRow.setAlignmentX(Component.LEFT_ALIGNMENT);
        buttonsRow.setMaximumSize(new Dimension(196, 34));
        JButton openCfg = miniButton(ICON_OPEN);
        openCfg.setToolTipText("Открыть папку клиента");
        openCfg.addActionListener(e -> openDir());
        JButton logOut = miniButton(ICON_LOGOUT);
        logOut.setToolTipText("Выйти из аккаунта");
        logOut.addActionListener(e -> doLogout());
        buttonsRow.add(openCfg);
        buttonsRow.add(logOut);
        accountBox.add(buttonsRow);
        sidebar.add(accountBox);

        main.add(sidebar, BorderLayout.WEST);

        JPanel content = new JPanel(new BorderLayout(0, 0));
        content.setOpaque(false);
        subLayout = new CardLayout();
        subCards = new JPanel(subLayout);
        subCards.setOpaque(false);
        subCards.add(buildHomePage(), "home");
        subCards.add(buildProfilePage(), "profile");
        subCards.add(buildNewsPage(), "news");
        subCards.add(buildSettingsPage(), "settings");
        subCards.add(buildAddonsPage(), "addons");
        subCards.add(buildScreenshotsPage(), "screenshots");
        content.add(subCards, BorderLayout.CENTER);
        main.add(content, BorderLayout.CENTER);

        return main;
    }

    private JButton miniButton(int iconType) {
        JButton b = new JButton() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(BTN);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), getHeight() / 2, getHeight() / 2);
                g2.setColor(TEXT);
                g2.setStroke(new BasicStroke(1.8f));
                int cx = getWidth() / 2;
                int cy = getHeight() / 2;
                if (iconType == ICON_FOLDER) {
                    drawFolder(g2, cx, cy);
                } else if (iconType == ICON_LOGOUT) {
                    drawLogout(g2, cx, cy);
                } else if (iconType == ICON_OPEN) {
                    drawOpen(g2, cx, cy);
                }
                g2.dispose();
            }
        };
        b.setPreferredSize(new Dimension(34, 30));
        b.setFocusPainted(false);
        b.setBorderPainted(false);
        b.setContentAreaFilled(false);
        b.setOpaque(false);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return b;
    }

    private static void drawFolder(Graphics2D g2, int cx, int cy) {
        int w = 18, h = 14;
        int x = cx - w / 2, y = cy - h / 2;
        Path2D.Double tab = new Path2D.Double();
        tab.moveTo(x, y + 2);
        tab.lineTo(x, y + h);
        tab.lineTo(x + w, y + h);
        tab.lineTo(x + w, y + 4);
        tab.lineTo(x + 8, y + 4);
        tab.curveTo(x + 6, y + 4, x + 5, y + 2, x + 3, y + 2);
        tab.closePath();
        g2.draw(tab);
    }

    private static void drawOpen(Graphics2D g2, int cx, int cy) {
        int w = 18, h = 14;
        int x = cx - w / 2, y = cy - h / 2;
        g2.drawRoundRect(x, y + 2, w - 4, h - 2, 4, 4);
        g2.drawLine(x + 2, y + 5, x + 6, y + 5);
        g2.setStroke(new BasicStroke(1.2f));
        g2.drawLine(x + w, y + 3, x + w, y - 2);
        g2.drawPolyline(new int[]{x + w - 2, x + w, x + w - 2}, new int[]{y - 1, y - 2, y - 4}, 3);
        g2.setStroke(new BasicStroke(1.8f));
    }

    private static void drawLogout(Graphics2D g2, int cx, int cy) {
        g2.drawRoundRect(cx - 7, cy - 8, 9, 16, 3, 3);
        g2.drawLine(cx + 2, cy - 5, cx + 7, cy - 2);
        g2.drawLine(cx + 7, cy - 2, cx + 2, cy + 1);
        g2.drawLine(cx + 2, cy - 5, cx + 2, cy + 1);
    }

    private static Icon iconDot(Color color) {
        return new Icon() {
            public void paintIcon(Component c, Graphics g, int x, int y) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(color);
                g2.fillOval(x, y, 12, 12);
                g2.dispose();
            }
            public int getIconWidth() {
                return 12;
            }
            public int getIconHeight() {
                return 12;
            }
        };
    }

    private static Icon iconDotPulse(Color color) {
        return new Icon() {
            public void paintIcon(Component c, Graphics g, int x, int y) {
                long now = System.currentTimeMillis();
                float t = (now % 2000) / 2000f;
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                int cx = x + 11;
                int cy = y + 11;
                float p = 1f - t;
                g2.setColor(new Color(color.getRed(), color.getGreen(), color.getBlue(), (int) (p * 90)));
                g2.fillOval((int) (cx - 11f - p * 5), (int) (cy - 11f - p * 5), (int) (22 + p * 10), (int) (22 + p * 10));
                g2.setColor(color);
                g2.fillOval(cx - 6, cy - 6, 12, 12);
                g2.dispose();
            }
            public int getIconWidth() {
                return 22;
            }
            public int getIconHeight() {
                return 22;
            }
        };
    }

    private void showView(String name) {
        SwingUtilities.invokeLater(() -> {
            subLayout.show(subCards, name);
            String t = name.equals("home") ? "Главная" : name.equals("profile") ? "Профиль"
                    : name.equals("news") ? "Новости" : name.equals("settings") ? "Настройки"
                    : name.equals("addons") ? "Дополнения" : "Скриншоты";
            titleLabel.setText(t);
            for (Map.Entry<String, TabButton> e : tabs.entrySet()) {
                e.getValue().setSelected(e.getKey().equals(name));
            }
        });
    }

    /* ═══════════════════════════════════════════════════════════════
       LOGIN SCREEN
       ═══════════════════════════════════════════════════════════════ */
    private JPanel buildLoginScreen() {
        JPanel page = new JPanel(new GridBagLayout());
        page.setOpaque(false);
        page.setBorder(BorderFactory.createEmptyBorder(10, 24, 24, 24));

        JPanel card = buildCard();
        card.setPreferredSize(new Dimension(440, 390));
        card.setMaximumSize(new Dimension(440, 390));
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBorder(BorderFactory.createEmptyBorder(30, 34, 28, 34));

        JLabel logo = new GradientLabel("HorusLauncher");
        logo.setFont(new Font("Segoe UI", Font.BOLD, 24));
        logo.setAlignmentX(Component.LEFT_ALIGNMENT);
        card.add(logo);
        card.add(Box.createRigidArea(new Dimension(0, 4)));

        JLabel sub = new JLabel("<html><span style='color:#9397b0;font-size:12px'>Логин и пароль от аккаунта на сайте HorusClient.<br>После входа откроется лаунчер.</span></html>");
        sub.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        sub.setForeground(TEXT_DIM);
        sub.setAlignmentX(Component.LEFT_ALIGNMENT);
        card.add(sub);
        card.add(Box.createRigidArea(new Dimension(0, 20)));

        loginField = new RoundedTextField();
        passwordField = new RoundedPasswordField();
        card.add(accountRow("Логин", loginField, ""));
        loginErrLabel = errorLabel();
        card.add(loginErrLabel);
        card.add(Box.createRigidArea(new Dimension(0, 8)));
        card.add(accountRow("Пароль", passwordField, ""));
        pwErrLabel = errorLabel();
        card.add(pwErrLabel);
        card.add(Box.createRigidArea(new Dimension(0, 14)));

        loginField.getDocument().addDocumentListener(new DocumentAdapter() {
            @Override public void changed() {
                clearLoginError();
            }
        });
        passwordField.getDocument().addDocumentListener(new DocumentAdapter() {
            @Override public void changed() {
                clearPwError();
            }
        });

        loginField.addActionListener(e -> doLogin());
        passwordField.addActionListener(e -> doLogin());

        loginBtn = new GlowButton("Войти в аккаунт", BTN);
        loginBtn.setPreferredSize(new Dimension(240, 40));
        loginBtn.setAlignmentX(Component.LEFT_ALIGNMENT);
        loginBtn.addActionListener(this::doLogin);
        card.add(loginBtn);
        card.add(Box.createRigidArea(new Dimension(0, 12)));

        authStatusLabel = new JLabel(" ");
        authStatusLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        authStatusLabel.setForeground(TEXT_DIM);
        authStatusLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        authStatusLabel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 18));
        card.add(authStatusLabel);

        page.add(card);
        return page;
    }

    private JLabel errorLabel() {
        JLabel l = new JLabel(" ");
        l.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        l.setForeground(DANGER);
        l.setAlignmentX(Component.LEFT_ALIGNMENT);
        l.setMaximumSize(new Dimension(Integer.MAX_VALUE, 16));
        return l;
    }

    private void markFieldError(JTextField field, boolean error) {
        Color border = error ? DANGER : BORDER;
        field.setBorder(BorderFactory.createCompoundBorder(new LineBorder(border, 1, true), new EmptyBorder(6, 10, 6, 10)));
    }

    private void clearLoginError() {
        if (loginErrLabel != null && !loginErrLabel.getText().isEmpty()) {
            loginErrLabel.setText(" ");
            markFieldError(loginField, false);
        }
    }

    private void clearPwError() {
        if (pwErrLabel != null && !pwErrLabel.getText().isEmpty()) {
            pwErrLabel.setText(" ");
            markFieldError(passwordField, false);
        }
    }

    private JPanel accountRow(String name, JTextField field, String tip) {
        JPanel row = new JPanel(new BorderLayout(12, 0));
        row.setOpaque(false);
        row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 34));
        JLabel l = new JLabel(name);
        l.setPreferredSize(new Dimension(56, 26));
        l.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        l.setForeground(TEXT_DIM);
        row.add(l, BorderLayout.WEST);
        field.setToolTipText(tip);
        styleTextField(field);
        row.add(field, BorderLayout.CENTER);
        return row;
    }

    /* ═══════════════════════════════════════════════════════════════
       CUSTOM COMPONENTS (карточки, кнопки, слайдеры)
       ═══════════════════════════════════════════════════════════════ */
    private JPanel buildCard() {
        JPanel card = new JPanel() {
            private float glowX = -1, glowY = -1;
            private boolean glowing = false;

            {
                addMouseMotionListener(new MouseMotionAdapter() {
                    public void mouseMoved(MouseEvent e) {
                        if (glowX != e.getX() || glowY != e.getY()) {
                            glowX = e.getX();
                            glowY = e.getY();
                            glowing = true;
                            repaint();
                        }
                    }
                    public void mouseDragged(MouseEvent e) {
                        mouseMoved(e);
                    }
                });
                addMouseListener(new MouseAdapter() {
                    public void mouseExited(MouseEvent e) {
                        glowing = false;
                        repaint();
                    }
                });
            }

            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(BG_CARD);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 15, 15);
                if (glowing && glowX >= 0) {
                    g2.setPaint(new RadialGradientPaint(
                            glowX, glowY, 220f,
                            new float[]{0f, 1f},
                            new Color[]{new Color(168, 85, 247, 40), new Color(168, 85, 247, 0)}));
                    g2.fillRoundRect(0, 0, getWidth(), getHeight(), 15, 15);
                }
                g2.setColor(BORDER);
                g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 15, 15);
            }
        };
        card.setOpaque(false);
        return card;
    }

    class RoundedPanel extends JPanel {
        private final Color fillColor;
        private final int arc;

        RoundedPanel(Color fillColor, int arc) {
            this.fillColor = fillColor;
            this.arc = arc;
            setOpaque(false);
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(fillColor);
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), arc, arc);
            g2.dispose();
        }
    }

    class RoundedProgressBar extends JProgressBar {
        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            int w = getWidth(), h = getHeight();
            int arc = h;
            g2.setColor(getBackground());
            g2.fillRoundRect(0, 0, w, h, arc, arc);
            int max = Math.max(getMaximum() - getMinimum(), 1);
            double frac = (getValue() - getMinimum()) / (double) max;
            int fillW = (int) Math.max(Math.round(w * frac), 0);
            if (fillW > 0) {
                g2.setPaint(new LinearGradientPaint(0, 0, w, 0,
                        new float[]{0f, 1f},
                        new Color[]{ACCENT2, ACCENT}));
                g2.fillRoundRect(0, 0, fillW, h, arc, arc);
            }
            g2.dispose();
        }
    }

    class GradientLabel extends JLabel {
        private float gradPhase = 0f;

        GradientLabel(String text) {
            super(text);
            setOpaque(false);
            javax.swing.Timer t = new javax.swing.Timer(40, e -> {
                gradPhase += 0.02f;
                repaint();
            });
            t.start();
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            g2.setFont(getFont());
            FontMetrics fm = g2.getFontMetrics();
            String text = getText();
            int tw = fm.stringWidth(text);
            int tx = 0;
            int ty = (getHeight() + fm.getAscent() - fm.getDescent()) / 2;
            float shift = (float) (Math.sin(gradPhase) * tw * 0.35f);
            LinearGradientPaint gp = new LinearGradientPaint(
                    -tw * 0.5f - shift + tx, 0, tw * 1.5f - shift + tx, 0,
                    new float[]{0f, 0.5f, 1f},
                    new Color[]{ACCENT2, ACCENT, ACCENT2});
            g2.setPaint(gp);
            g2.drawString(text, tx, ty);
            g2.dispose();
        }
    }

    class RoundedTextField extends JTextField {
        RoundedTextField() {
            setOpaque(false);
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(INPUT_BG);
            g2.fillRoundRect(1, 1, getWidth() - 2, getHeight() - 2, 12, 12);
            g2.dispose();
            super.paintComponent(g);
        }
    }

    class RoundedPasswordField extends JPasswordField {
        RoundedPasswordField() {
            setOpaque(false);
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(INPUT_BG);
            g2.fillRoundRect(1, 1, getWidth() - 2, getHeight() - 2, 12, 12);
            g2.dispose();
            super.paintComponent(g);
        }
    }

    private void styleTextField(JTextField field) {
        field.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        field.setForeground(TEXT);
        field.setBackground(INPUT_BG);
        field.setCaretColor(ACCENT);
        field.setBorder(BorderFactory.createCompoundBorder(new LineBorder(BORDER, 1, true), new EmptyBorder(6, 10, 6, 10)));
        field.setOpaque(false);
    }

    abstract static class DocumentAdapter implements javax.swing.event.DocumentListener {
        public abstract void changed();

        @Override
        public void insertUpdate(javax.swing.event.DocumentEvent e) {
            changed();
        }

        @Override
        public void removeUpdate(javax.swing.event.DocumentEvent e) {
            changed();
        }

        @Override
        public void changedUpdate(javax.swing.event.DocumentEvent e) {
            changed();
        }
    }

    /* ═══════════════════════════════════════════════════════════════
       HOME PAGE
       ═══════════════════════════════════════════════════════════════ */
    private JPanel buildHomePage() {
        JPanel page = new JPanel();
        page.setOpaque(false);
        page.setBorder(BorderFactory.createEmptyBorder(18, 26, 18, 26));
        page.setLayout(new BoxLayout(page, BoxLayout.Y_AXIS));

        JPanel hero = buildCard();
        hero.setMaximumSize(new Dimension(Integer.MAX_VALUE, 250));
        hero.setLayout(new BoxLayout(hero, BoxLayout.Y_AXIS));
        hero.setBorder(BorderFactory.createEmptyBorder(26, 30, 22, 30));

        JLabel title = new GradientLabel("Добро пожаловать,");
        title.setFont(new Font("Segoe UI", Font.BOLD, 26));
        title.setAlignmentX(Component.LEFT_ALIGNMENT);
        hero.add(title);
        hero.add(Box.createRigidArea(new Dimension(0, 2)));

        JLabel titleUser = new GradientLabel(accountLogin.isEmpty() ? "гость" : accountLogin);
        titleUser.setFont(new Font("Segoe UI", Font.BOLD, 26));
        titleUser.setAlignmentX(Component.LEFT_ALIGNMENT);
        hero.add(titleUser);
        hero.add(Box.createRigidArea(new Dimension(0, 18)));

        launchBtn = new GlowButton("Запустить", BTN);
        launchBtn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 44));
        launchBtn.setPreferredSize(new Dimension(360, 44));
        launchBtn.setAlignmentX(Component.LEFT_ALIGNMENT);
        launchBtn.addActionListener(() -> new Thread(this::doLaunch, "launch").start());
        hero.add(launchBtn);
        hero.add(Box.createRigidArea(new Dimension(0, 14)));

        JPanel progWrap = new JPanel();
        progWrap.setOpaque(false);
        progWrap.setAlignmentX(Component.LEFT_ALIGNMENT);
        progWrap.setMaximumSize(new Dimension(Integer.MAX_VALUE, 44));
        progWrap.setLayout(new BorderLayout(0, 6));
        progressBar = new RoundedProgressBar();
        progressBar.setValue(0);
        progressBar.setStringPainted(false);
        progressBar.setPreferredSize(new Dimension(0, 6));
        progressBar.setBorderPainted(false);
        progressBar.setBackground(new Color(24, 32, 54));
        progressBar.setForeground(ACCENT);
        progWrap.add(progressBar, BorderLayout.SOUTH);
        statusLabel = new JLabel("Готов к работе");
        statusLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        statusLabel.setForeground(ACCENT);
        statusLabel.setHorizontalAlignment(SwingConstants.LEFT);
        progWrap.add(statusLabel, BorderLayout.NORTH);
        hero.add(progWrap);

        page.add(hero);
        page.add(Box.createRigidArea(new Dimension(0, 14)));

        JPanel news = buildCard();
        news.setMaximumSize(new Dimension(Integer.MAX_VALUE, 210));
        news.setLayout(new BorderLayout(0, 6));
        news.setBorder(BorderFactory.createEmptyBorder(16, 24, 16, 24));
        JLabel newsTitle = new JLabel("ОБНОВЛЕНИЯ");
        newsTitle.setFont(new Font("Segoe UI", Font.BOLD, 12));
        newsTitle.setForeground(TEXT_DIM);
        news.add(newsTitle, BorderLayout.NORTH);
        JTextArea newsArea = new JTextArea(NEWS_TEXT);
        newsArea.setEditable(false);
        newsArea.setOpaque(false);
        newsArea.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        newsArea.setForeground(TEXT);
        newsArea.setLineWrap(true);
        newsArea.setWrapStyleWord(true);
        newsArea.setBorder(BorderFactory.createEmptyBorder(6, 0, 0, 0));
        news.add(newsArea, BorderLayout.CENTER);
        page.add(news);
        page.add(Box.createVerticalGlue());
        return page;
    }

    /* ═══════════════════════════════════════════════════════════════
       PROFILE PAGE
       ═══════════════════════════════════════════════════════════════ */
    private JPanel buildProfilePage() {
        JPanel page = new JPanel();
        page.setOpaque(false);
        page.setBorder(BorderFactory.createEmptyBorder(18, 26, 18, 26));
        page.setLayout(new BoxLayout(page, BoxLayout.Y_AXIS));

        JPanel card = buildCard();
        card.setMaximumSize(new Dimension(Integer.MAX_VALUE, 260));
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBorder(BorderFactory.createEmptyBorder(22, 28, 22, 28));

        JLabel lbl = new JLabel("Профиль: " + (accountLogin.isEmpty() ? "гость" : accountLogin));
        lbl.setFont(new Font("Segoe UI", Font.BOLD, 22));
        lbl.setForeground(ACCENT);
        lbl.setAlignmentX(Component.LEFT_ALIGNMENT);
        card.add(lbl);
        card.add(Box.createRigidArea(new Dimension(0, 10)));

        card.add(profileRow("Подписка", accountRole, SUCCESS));
        card.add(Box.createRigidArea(new Dimension(0, 6)));
        card.add(profileRow("UID", accountUid.isEmpty() ? "Неизвестно" : accountUid, TEXT_DIM));
        card.add(Box.createRigidArea(new Dimension(0, 6)));
        card.add(profileRow("Подписка до", accountExpiry, TEXT_DIM));
        card.add(Box.createRigidArea(new Dimension(0, 6)));
        card.add(profileRow("HWID", getCurrentHwid(), TEXT_DIM));
        card.add(Box.createRigidArea(new Dimension(0, 14)));

        GlowButton logoutBtn = new GlowButton("Выйти из аккаунта", DANGER);
        logoutBtn.setPreferredSize(new Dimension(210, 38));
        logoutBtn.setAlignmentX(Component.LEFT_ALIGNMENT);
        logoutBtn.addActionListener(() -> new Thread(this::doLogout, "logout").start());
        card.add(logoutBtn);

        page.add(card);
        page.add(Box.createRigidArea(new Dimension(0, 14)));

        JPanel stats = buildCard();
        stats.setMaximumSize(new Dimension(Integer.MAX_VALUE, 220));
        stats.setLayout(new BoxLayout(stats, BoxLayout.Y_AXIS));
        stats.setBorder(BorderFactory.createEmptyBorder(22, 28, 22, 28));

        JLabel statsTitle = new JLabel("ВАША СТАТИСТИКА");
        statsTitle.setFont(new Font("Segoe UI", Font.BOLD, 12));
        statsTitle.setForeground(TEXT_DIM);
        statsTitle.setAlignmentX(Component.LEFT_ALIGNMENT);
        stats.add(statsTitle);
        stats.add(Box.createRigidArea(new Dimension(0, 10)));

        JsonObject st = loadStats();
        long total = st.has("total_seconds") ? (long) Double.parseDouble(st.getString("total_seconds").replace("\"", "")) : 0;
        long hours = total / 3600, mins = (total % 3600) / 60;
        stats.add(profileRow("Часов в игре", hours + " ч " + mins + " мин", ACCENT));
        stats.add(Box.createRigidArea(new Dimension(0, 6)));
        String topServers = topServersText(st);
        stats.add(profileRow("Топ серверы", topServers.isEmpty() ? "—" : topServers, TEXT_DIM));

        page.add(stats);
        page.add(Box.createVerticalGlue());
        return page;
    }

    private JPanel profileRow(String name, String value, Color c) {
        JPanel row = new JPanel(new BorderLayout(12, 0));
        row.setOpaque(false);
        row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 22));
        JLabel l = new JLabel(name);
        l.setPreferredSize(new Dimension(130, 22));
        l.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        l.setForeground(TEXT_DIM);
        row.add(l, BorderLayout.WEST);
        JLabel v = new JLabel(value);
        v.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 13));
        v.setForeground(c);
        v.setToolTipText(value);
        row.add(v, BorderLayout.CENTER);
        return row;
    }

    /* ═══════════════════════════════════════════════════════════════
       NEWS PAGE
       ═══════════════════════════════════════════════════════════════ */
    private JPanel buildNewsPage() {
        JPanel page = new JPanel();
        page.setOpaque(false);
        page.setBorder(BorderFactory.createEmptyBorder(18, 26, 18, 26));
        page.setLayout(new BorderLayout(0, 0));

        JPanel card = buildCard();
        card.setLayout(new BorderLayout(0, 6));
        card.setBorder(BorderFactory.createEmptyBorder(20, 26, 20, 26));
        JLabel title = new JLabel("Новости обновлений");
        title.setFont(new Font("Segoe UI", Font.BOLD, 20));
        title.setForeground(ACCENT);
        card.add(title, BorderLayout.NORTH);
        JTextArea newsArea = new JTextArea(NEWS_TEXT);
        newsArea.setEditable(false);
        newsArea.setOpaque(false);
        newsArea.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        newsArea.setForeground(TEXT);
        newsArea.setLineWrap(true);
        newsArea.setWrapStyleWord(true);
        newsArea.setBorder(BorderFactory.createEmptyBorder(12, 0, 0, 0));
        card.add(newsArea, BorderLayout.CENTER);
        page.add(card, BorderLayout.CENTER);
        return page;
    }

    /* ═══════════════════════════════════════════════════════════════
       SETTINGS PAGE
       ═══════════════════════════════════════════════════════════════ */
    private JPanel buildSettingsPage() {
        JPanel page = new JPanel();
        page.setOpaque(false);
        page.setBorder(BorderFactory.createEmptyBorder(18, 26, 18, 26));
        page.setLayout(new BoxLayout(page, BoxLayout.Y_AXIS));

        int totalRam = totalRamGb();
        ramGb = Math.max(2, Math.min(totalRam, ramGb));

        JPanel ramCard = buildCard();
        ramCard.setMaximumSize(new Dimension(Integer.MAX_VALUE, 150));
        ramCard.setLayout(new BoxLayout(ramCard, BoxLayout.Y_AXIS));
        ramCard.setBorder(BorderFactory.createEmptyBorder(18, 26, 18, 26));
        JLabel ramTitle = new JLabel("Оперативная память");
        ramTitle.setFont(new Font("Segoe UI", Font.BOLD, 15));
        ramTitle.setForeground(TEXT);
        ramTitle.setAlignmentX(Component.LEFT_ALIGNMENT);
        ramCard.add(ramTitle);
        ramCard.add(Box.createRigidArea(new Dimension(0, 10)));

        ramSlider = new RamSlider(2, totalRam, ramGb);
        ramSlider.setAlignmentX(Component.LEFT_ALIGNMENT);
        ramSlider.setMaximumSize(new Dimension(Integer.MAX_VALUE, 44));
        ramSlider.setPreferredSize(new Dimension(900, 44));
        ramCard.add(ramSlider);
        ramCard.add(Box.createRigidArea(new Dimension(0, 6)));

        JLabel ramValue = new JLabel(ramGb + " GB");
        ramValue.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 13));
        ramValue.setForeground(ACCENT);
        ramValue.setAlignmentX(Component.LEFT_ALIGNMENT);
        ramCard.add(ramValue);

        JLabel ramMax = new JLabel("Доступно: " + totalRam + " GB");
        ramMax.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        ramMax.setForeground(TEXT_DIM);
        ramMax.setAlignmentX(Component.LEFT_ALIGNMENT);
        ramCard.add(ramMax);

        ramSlider.setOnChanged(() -> {
            ramGb = ramSlider.getValue();
            SwingUtilities.invokeLater(() -> ramValue.setText(ramGb + " GB"));
            updateLauncherConfig("ram", String.valueOf(ramGb));
        });
        page.add(ramCard);
        page.add(Box.createRigidArea(new Dimension(0, 14)));

        JPanel folderCard = buildCard();
        folderCard.setMaximumSize(new Dimension(Integer.MAX_VALUE, 64));
        folderCard.setLayout(new BorderLayout(12, 0));
        folderCard.setBorder(BorderFactory.createEmptyBorder(10, 26, 10, 20));
        JLabel folderLabel = new JLabel("Папка игры");
        folderLabel.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        folderLabel.setForeground(TEXT);
        folderCard.add(folderLabel, BorderLayout.WEST);
        GlowButton openFolder = new GlowButton("Открыть папку", BTN);
        openFolder.setPreferredSize(new Dimension(170, 36));
        openFolder.addActionListener(() -> openDir());
        folderCard.add(openFolder, BorderLayout.EAST);
        page.add(folderCard);

        page.add(Box.createVerticalGlue());
        return page;
    }

    /* ═══════════════════════════════════════════════════════════════
       ADDONS PAGE (Modrinth)
       ═══════════════════════════════════════════════════════════════ */
    private JPanel buildAddonsPage() {
        JPanel page = new JPanel();
        page.setOpaque(false);
        page.setBorder(BorderFactory.createEmptyBorder(18, 26, 18, 26));
        page.setLayout(new BorderLayout(0, 12));

        JLabel title = new JLabel("Дополнения (Modrinth)");
        title.setFont(new Font("Segoe UI", Font.BOLD, 18));
        title.setForeground(ACCENT);
        page.add(title, BorderLayout.NORTH);

        JPanel mid = new JPanel(new BorderLayout(0, 10));
        mid.setOpaque(false);

        JPanel searchRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        searchRow.setOpaque(false);
        addonSearchField = new RoundedTextField();
        addonSearchField.setPreferredSize(new Dimension(320, 36));
        styleTextField(addonSearchField);
        addonSearchField.getDocument().addDocumentListener(new DocumentAdapter() {
            @Override public void changed() {
                markFieldError(addonSearchField, false);
            }
        });
        addonSearchField.addActionListener(e -> searchAddons());
        searchRow.add(addonSearchField);
        GlowButton searchBtn = new GlowButton("Поиск", BTN);
        searchBtn.setPreferredSize(new Dimension(110, 36));
        searchBtn.addActionListener(() -> searchAddons());
        searchRow.add(searchBtn);
        GlowButton folderBtn = new GlowButton(ICON_FOLDER, BTN);
        folderBtn.setPreferredSize(new Dimension(54, 36));
        folderBtn.setToolTipText("Открыть папку модов");
        folderBtn.addActionListener(() -> openModsFolder());
        searchRow.add(folderBtn);
        mid.add(searchRow, BorderLayout.NORTH);

        addonsListPanel = new JPanel();
        addonsListPanel.setOpaque(false);
        addonsListPanel.setLayout(new BoxLayout(addonsListPanel, BoxLayout.Y_AXIS));
        JScrollPane scroll = new JScrollPane(addonsListPanel);
        scroll.setBorder(null);
        scroll.getViewport().setBackground(BG_CARD);
        scroll.getVerticalScrollBar().setUI(new ModernScrollBarUI());
        scroll.getHorizontalScrollBar().setUI(new ModernScrollBarUI());
        scroll.getVerticalScrollBar().setBackground(BG_CARD);
        scroll.getHorizontalScrollBar().setBackground(BG_CARD);
        scroll.setBorder(new LineBorder(BORDER, 1, true));
        scroll.getViewport().setOpaque(false);
        scroll.setOpaque(false);
        scroll.setBackground(BG_DARK);
        scroll.getVerticalScrollBar().setUI(new ModernScrollBarUI());
        mid.add(scroll, BorderLayout.CENTER);
        page.add(mid, BorderLayout.CENTER);
        return page;
    }

    private void openModsFolder() {
        try {
            Path p = gameDirOrDef().resolve("mods");
            Files.createDirectories(p);
            Desktop.getDesktop().open(p.toFile());
        } catch (Exception e) {
            log("Не удалось открыть папку модов: " + e.getMessage());
        }
    }

    private void searchAddons() {
        String query = addonSearchField.getText().trim();
        if (query.isEmpty()) {
            markFieldError(addonSearchField, true);
            showToast("Введите запрос для поиска");
            addonsListPanel.removeAll();
            let("Должно быть заполнено поле поиска");
            addonsListPanel.revalidate();
            return;
        }
        addonsListPanel.removeAll();
        let("Поиск дополнений...");
        JLabel ph = new JLabel("Поиск...");
        ph.setForeground(TEXT_DIM);
        addonsListPanel.add(ph);
        addonsListPanel.revalidate();
        new Thread(() -> {
            try {
                String url = MODRINTH_SEARCH + java.net.URLEncoder.encode(query, StandardCharsets.UTF_8) + MODRINTH_FACETS;
                HttpRequest req = HttpRequest.newBuilder(URI.create(url))
                        .timeout(Duration.ofSeconds(25))
                        .header("User-Agent", "HorusLauncher/1.0")
                        .GET().build();
                HttpResponse<String> resp = http.send(req, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
                if (resp.statusCode() / 100 != 2) throw new IOException("HTTP " + resp.statusCode());
                JsonObject body = parseJsonSafe(resp.body());
                if (body == null || !body.has("hits")) throw new IOException("Некорректный ответ");
                List<JsonValue> hits = body.getArray("hits").values;
                List<String[]> rows = new ArrayList<>();
                for (JsonValue h : hits) {
                    JsonObject o = h.asObject();
                    String id = o.has("project_id") ? o.getString("project_id") : "";
                    String name = o.has("title") ? o.getString("title") : "?";
                    String installed = isModInstalled(name) ? "true" : "false";
                    rows.add(new String[]{id, name, installed});
                }
                SwingUtilities.invokeLater(() -> renderAddonResults(rows));
            } catch (Exception e) {
                log("Ошибка поиска дополнений: " + e);
                SwingUtilities.invokeLater(() -> {
                    addonsListPanel.removeAll();
                    let("Ошибка поиска: " + e.getMessage());
                });
            }
        }, "addons-search").start();
    }

    private void let(String s) {
        JLabel l = new JLabel(s);
        l.setForeground(TEXT_DIM);
        l.setBorder(BorderFactory.createEmptyBorder(6, 4, 6, 4));
        addonsListPanel.add(l);
        addonsListPanel.revalidate();
        addonsListPanel.repaint();
    }

    private boolean isModInstalled(String name) {
        Path mods = gameDirOrDef().resolve("mods");
        if (!Files.isDirectory(mods)) return false;
        try {
            for (String f : Files.list(mods).map(p -> p.getFileName().toString().toLowerCase(Locale.ROOT)).toArray(String[]::new)) {
                if (f.contains(name.toLowerCase(Locale.ROOT)) && f.endsWith(".jar")) return true;
            }
        } catch (Exception ignored) {
        }
        return false;
    }

    private void renderAddonResults(List<String[]> rows) {
        addonsListPanel.removeAll();
        if (rows.isEmpty()) {
            let("Ничего не найдено.");
            return;
        }
        for (String[] r : rows) {
            addonsListPanel.add(addonRow(r[0], r[1], "true".equals(r[2])));
            addonsListPanel.add(Box.createRigidArea(new Dimension(0, 8)));
        }
        addonsListPanel.revalidate();
        addonsListPanel.repaint();
    }

    private JPanel addonRow(String id, String name, boolean installed) {
        JPanel row = buildCard();
        row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 54));
        row.setLayout(new BorderLayout(12, 0));
        row.setBorder(BorderFactory.createEmptyBorder(8, 18, 8, 12));
        JLabel n = new JLabel(name);
        n.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        n.setForeground(TEXT);
        row.add(n, BorderLayout.WEST);
        if (installed) {
            JLabel ok = new JLabel("Установлен ✓");
            ok.setFont(new Font("Segoe UI", Font.PLAIN, 12));
            ok.setForeground(SUCCESS);
            row.add(ok, BorderLayout.EAST);
        } else {
            GlowButton dl = new GlowButton("Скачать", BTN);
            dl.setPreferredSize(new Dimension(118, 34));
            final String fid = id, fname = name;
            dl.addActionListener(() -> new Thread(() -> installModrinthMod(fid, fname), "addon-install").start());
            row.add(dl, BorderLayout.EAST);
        }
        return row;
    }

    private void installModrinthMod(String projectId, String name) {
        try {
            showDownload("Загрузка: " + name + "...");
            String versionsUrl = MODRINTH_VERSIONS + projectId + "/version?game_versions=%5B%221.21.4%22%5D&loaders=%5B%22fabric%22%5D";
            HttpRequest req = HttpRequest.newBuilder(URI.create(versionsUrl))
                    .timeout(Duration.ofSeconds(25))
                    .header("User-Agent", "HorusLauncher/1.0")
                    .GET().build();
            HttpResponse<String> resp = http.send(req, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
            JsonArray list = Json.parse(resp.body()).asArray();
            if (list.isEmpty()) throw new IOException("Нет файла для 1.21.4 / fabric");
            JsonObject file = list.get(0).asObject().getArray("files").get(0).asObject();
            String filename = file.has("filename") ? file.getString("filename") : projectId + ".jar";
            Path target = gameDirOrDef().resolve("mods").resolve(filename);
            downloadWithProgress(file.getString("url"), target);
            SwingUtilities.invokeLater(() -> {
                showToast("Установлено: " + name);
                searchAddons();
            });
        } catch (Exception e) {
            log("Ошибка установки мода: " + e.getMessage());
            showToast("Ошибка установки: " + e.getMessage());
        } finally {
            hideDownload();
        }
    }

    /* ═══════════════════════════════════════════════════════════════
       SCREENSHOTS PAGE
       ═══════════════════════════════════════════════════════════════ */
    private JPanel buildScreenshotsPage() {
        JPanel page = new JPanel();
        page.setOpaque(false);
        page.setBorder(BorderFactory.createEmptyBorder(18, 26, 18, 26));
        page.setLayout(new BorderLayout(0, 12));

        JPanel head = new JPanel(new BorderLayout(12, 0));
        head.setOpaque(false);
        JLabel title = new JLabel("Скриншоты игры");
        title.setFont(new Font("Segoe UI", Font.BOLD, 18));
        title.setForeground(ACCENT);
        head.add(title, BorderLayout.WEST);
        GlowButton open = new GlowButton("Открыть папку", BTN);
        open.setPreferredSize(new Dimension(170, 36));
        open.addActionListener(() -> {
            try {
                Path p = gameDirOrDef().resolve("screenshots");
                Files.createDirectories(p);
                Desktop.getDesktop().open(p.toFile());
            } catch (Exception ex) {
                log("Не удалось открыть скриншоты: " + ex.getMessage());
            }
        });
        head.add(open, BorderLayout.EAST);
        page.add(head, BorderLayout.NORTH);

        JPanel list = new JPanel();
        list.setOpaque(false);
        list.setLayout(new BoxLayout(list, BoxLayout.Y_AXIS));
        Path shots = gameDirOrDef().resolve("screenshots");
        try {
            if (Files.isDirectory(shots)) {
                List<String> files = new ArrayList<>();
                try (StreamFinder sf = new StreamFinder(shots)) {
                    files.addAll(sf.files);
                }
                for (String f : files) {
                    JLabel row = new JLabel(f, new Icon() {
                        public void paintIcon(Component c, Graphics g, int x, int y) {
                            Graphics2D g2 = (Graphics2D) g.create();
                            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                            g2.setColor(TEXT_DIM);
                            g2.setStroke(new BasicStroke(1.4f));
                            g2.drawRoundRect(x, y, 14, 11, 3, 3);
                            g2.drawOval(x + 8, y + 2, 3, 3);
                            g2.drawLine(x + 2, y + 9, x + 5, y + 5);
                            g2.drawLine(x + 5, y + 5, x + 12, y + 8);
                            g2.dispose();
                        }
                        public int getIconWidth() {
                            return 14;
                        }
                        public int getIconHeight() {
                            return 11;
                        }
                    }, JLabel.LEFT);
                    row.setFont(new Font("Segoe UI", Font.PLAIN, 13));
                    row.setForeground(TEXT);
                    row.setBorder(BorderFactory.createEmptyBorder(8, 10, 8, 10));
                    list.add(row);
                }
                if (files.isEmpty()) {
                    JLabel none = new JLabel("Скриншотов пока нет.");
                    none.setForeground(TEXT_DIM);
                    list.add(none);
                }
            } else {
                JLabel none = new JLabel("Папка C:\\Horus\\screenshots пока пуста.");
                none.setForeground(TEXT_DIM);
                list.add(none);
            }
        } catch (Exception e) {
            log("Ошибка чтения скриншотов: " + e.getMessage());
        }
        JScrollPane scroll = new JScrollPane(list);
        scroll.setBorder(null);
        scroll.getViewport().setBackground(BG_CARD);
        scroll.getVerticalScrollBar().setUI(new ModernScrollBarUI());
        scroll.getHorizontalScrollBar().setUI(new ModernScrollBarUI());
        scroll.getVerticalScrollBar().setBackground(BG_CARD);
        scroll.getHorizontalScrollBar().setBackground(BG_CARD);
        scroll.setBorder(new LineBorder(BORDER, 1, true));
        scroll.getViewport().setOpaque(false);
        scroll.setOpaque(false);
        scroll.getVerticalScrollBar().setUI(new ModernScrollBarUI());
        page.add(scroll, BorderLayout.CENTER);
        return page;
    }

    static class StreamFinder implements AutoCloseable {
        final List<String> files = new ArrayList<>();
        StreamFinder(Path dir) throws IOException {
            try (var s = Files.list(dir)) {
                s.filter(f -> {
                    String n = f.getFileName().toString().toLowerCase(Locale.ROOT);
                    return n.endsWith(".png") || n.endsWith(".jpg") || n.endsWith(".jpeg");
                }).sorted().forEach(f -> files.add(f.getFileName().toString()));
            }
        }
        @Override public void close() {
        }
    }

    /* ═══════════════════════════════════════════════════════════════
       SUPPORT PAGE (Gemini ИИ)
       ═══════════════════════════════════════════════════════════════ */
    class GlowButton extends JPanel {
        private final String text;
        private final int iconType;
        private final Color baseColor;
        private boolean hovered = false;
        private boolean pressed = false;
        private boolean enabled = true;
        private float shinePhase = 0f;
        private Runnable onClickAction;
        private final javax.swing.Timer shineTimer;

        GlowButton(String text, Color color) {
            this(text, 0, color);
        }

        GlowButton(int iconType, Color color) {
            this(null, iconType, color);
        }

        private GlowButton(String text, int iconType, Color color) {
            this.text = text;
            this.iconType = iconType;
            this.baseColor = color;
            setPreferredSize(new Dimension(200, 38));
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            setOpaque(false);
            shineTimer = new javax.swing.Timer(33, e -> {
                shinePhase += 0.06f;
                if (shinePhase > 4f) shinePhase = 0f;
                repaint();
            });
            shineTimer.setRepeats(true);
            addMouseListener(new MouseAdapter() {
                public void mouseEntered(MouseEvent e) {
                    hovered = true;
                    if (!shineTimer.isRunning()) shineTimer.start();
                    repaint();
                }
                public void mouseExited(MouseEvent e) {
                    hovered = false;
                    pressed = false;
                    shineTimer.stop();
                    repaint();
                }
                public void mousePressed(MouseEvent e) {
                    if (!enabled) return;
                    pressed = true;
                    repaint();
                }
                public void mouseReleased(MouseEvent e) {
                    pressed = false;
                    if (hovered && enabled && onClickAction != null) onClickAction.run();
                }
            });
        }

        void addActionListener(Runnable r) {
            this.onClickAction = r;
        }

        public void setEnabled(boolean e) {
            this.enabled = e;
            setCursor(e ? Cursor.getPredefinedCursor(Cursor.HAND_CURSOR) : Cursor.getDefaultCursor());
            repaint();
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            int w = getWidth(), h = getHeight();
            int r = h >= 36 ? h / 2 : 12;

            if (hovered && enabled) {
                g2.setColor(new Color(ACCENT.getRed(), ACCENT.getGreen(), ACCENT.getBlue(), 36));
                g2.fillRoundRect(-3, -3, w + 6, h + 6, r + 4, r + 4);
            }
            Color bg = !enabled ? new Color(45, 55, 85) : pressed ? baseColor.darker() : hovered ? BTN_HOVER : shade(baseColor, -1);
            if (baseColor == BTN) bg = !enabled ? new Color(45, 55, 85) : pressed ? BTN_HOVER.darker() : hovered ? BTN_HOVER : BTN;
            g2.setColor(bg);
            g2.fillRoundRect(0, 0, w, h, r, r);
            if (shineTimer.isRunning() && enabled) {
                Shape clip = g2.getClip();
                g2.clip(new java.awt.geom.RoundRectangle2D.Float(0, 0, w, h, r, r));
                float sweepX = ((shinePhase % 1.2f) / 1.2f) * (w + 120f) - 60f;
                g2.setPaint(new LinearGradientPaint(
                        sweepX - 50, 0, sweepX + 60, 0,
                        new float[]{0f, 0.5f, 1f},
                        new Color[]{new Color(255, 255, 255, 0), new Color(255, 255, 255, 90), new Color(255, 255, 255, 0)}));
                g2.fillRoundRect(0, 0, w, h, r, r);
                g2.setClip(clip);
            }
            g2.setColor(!enabled ? new Color(255, 255, 255, 90) : TEXT);
            if (iconType == ICON_FOLDER) {
                g2.setStroke(new BasicStroke(1.8f));
                int cx = w / 2, cy = h / 2 - 1;
                int iw = 18, ih = 14;
                int x = cx - iw / 2, y = cy - ih / 2;
                g2.drawRoundRect(x, y + 2, iw, ih - 2, 4, 4);
                g2.drawLine(x + 2, y + 5, x + 6, y + 5);
            } else {
                g2.setFont(new Font("Segoe UI", Font.BOLD, 13));
                FontMetrics fm = g2.getFontMetrics();
                int tx = (w - fm.stringWidth(text)) / 2;
                int ty = (h + fm.getAscent() - fm.getDescent()) / 2;
                g2.drawString(text, tx, ty);
            }
            g2.dispose();
        }

        private Color shade(Color c, int dir) {
            return c;
        }
    }

    /* ═══════════════════════════════════════════════════════════════
       TAB BUTTON (sidebar)
       ═══════════════════════════════════════════════════════════════ */
    class TabButton extends JPanel {
        private final String label;
        private boolean selected = false;
        private boolean hovered = false;
        private Runnable onClick;

        TabButton(String label) {
            this.label = label;
            setPreferredSize(new Dimension(196, 40));
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            setOpaque(false);
            addMouseListener(new MouseAdapter() {
                public void mouseEntered(MouseEvent e) {
                    hovered = true;
                    repaint();
                }
                public void mouseExited(MouseEvent e) {
                    hovered = false;
                    repaint();
                }
                public void mousePressed(MouseEvent e) {
                    if (onClick != null) onClick.run();
                    selected = true;
                    repaint();
                }
            });
        }

        void setOnClick(Runnable r) {
            this.onClick = r;
        }

        void setSelected(boolean sel) {
            selected = sel;
            repaint();
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            int w = getWidth(), h = getHeight(), r = h / 2;
            if (selected) {
                g2.setColor(new Color(ACCENT.getRed(), ACCENT.getGreen(), ACCENT.getBlue(), 30));
                g2.fillRoundRect(0, 2, w, h - 4, r, r);
                g2.setColor(ACCENT);
                g2.setStroke(new BasicStroke(1f));
                g2.drawRoundRect(0, 2, w, h - 4, r, r);
            } else if (hovered) {
                g2.setColor(new Color(45, 55, 85, 160));
                g2.fillRoundRect(0, 2, w, h - 4, r, r);
            }
            g2.setColor(selected ? ACCENT : (hovered ? TEXT : TEXT_DIM));
            g2.setFont(new Font("Segoe UI", selected ? Font.BOLD : Font.PLAIN, 13));
            FontMetrics fm = g2.getFontMetrics();
            g2.drawString(label, 14, (h + fm.getAscent() - fm.getDescent()) / 2);
        }
    }

    /* ═══════════════════════════════════════════════════════════════
       CIRCLE BUTTON (minimize / close)
       ═══════════════════════════════════════════════════════════════ */
    class CircleButton extends JPanel {
        private final String label;
        private final Color color;
        private boolean hovered = false;
        private final List<Runnable> actions = new ArrayList<>();

        CircleButton(String label, Color color) {
            this.label = label;
            this.color = color;
            setPreferredSize(new Dimension(28, 28));
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            setOpaque(false);
            addMouseListener(new MouseAdapter() {
                public void mouseEntered(MouseEvent e) {
                    hovered = true;
                    repaint();
                }
                public void mouseExited(MouseEvent e) {
                    hovered = false;
                    repaint();
                }
                public void mousePressed(MouseEvent e) {
                    actions.forEach(Runnable::run);
                }
            });
        }

        void addActionListener(Runnable r) {
            actions.add(r);
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            int s = Math.min(getWidth(), getHeight());
            int x = (getWidth() - s) / 2, y = (getHeight() - s) / 2;
            g2.setColor(hovered ? color : new Color(color.getRed(), color.getGreen(), color.getBlue(), 150));
            g2.fillOval(x, y, s, s);
            g2.setColor(TEXT);
            g2.setFont(new Font("Segoe UI", Font.BOLD, 12));
            FontMetrics fm = g2.getFontMetrics();
            g2.drawString(label, (getWidth() - fm.stringWidth(label)) / 2, (getHeight() + fm.getAscent() - fm.getDescent()) / 2);
        }
    }

    /* ═══════════════════════════════════════════════════════════════
       RAM SLIDER
       ═══════════════════════════════════════════════════════════════ */
    class RamSlider extends JPanel {
        private final int min, max;
        private int value;
        private float animValue;
        private boolean dragging = false;
        private boolean hovered = false;
        private Runnable onChanged;
        private final MouseAdapter mouse;

        RamSlider(int min, int max, int value) {
            this.min = min;
            this.max = max;
            this.value = value;
            this.animValue = value;
            setOpaque(false);
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            mouse = new MouseAdapter() {
                public void mouseEntered(MouseEvent e) {
                    hovered = true;
                    repaint();
                }
                public void mouseExited(MouseEvent e) {
                    hovered = false;
                    repaint();
                }
                public void mousePressed(MouseEvent e) {
                    dragging = true;
                    updateFromX(e.getX());
                }
                public void mouseDragged(MouseEvent e) {
                    if (dragging) updateFromX(e.getX());
                }
                public void mouseReleased(MouseEvent e) {
                    dragging = false;
                    repaint();
                }
            };
            addMouseListener(mouse);
            addMouseMotionListener(mouse);
            javax.swing.Timer t = new javax.swing.Timer(20, e -> {
                animValue += (RamSlider.this.value - animValue) * 0.18f;
                if (Math.abs(animValue - RamSlider.this.value) < 0.05f) animValue = RamSlider.this.value;
                repaint();
            });
            t.start();
        }

        void setOnChanged(Runnable r) {
            this.onChanged = r;
        }

        int getValue() {
            return value;
        }

        private void updateFromX(int x) {
            int left = 16;
            int trackW = Math.max(getWidth() - 32, 1);
            float frac = (x - left) / (float) trackW;
            frac = Math.max(0f, Math.min(1f, frac));
            int v = Math.round(min + (max - min) * frac);
            if (v != value) {
                value = v;
                if (onChanged != null) onChanged.run();
            }
            repaint();
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            int cy = getHeight() / 2;
            int h = 8;
            int left = 16, right = Math.max(getWidth() - 32, left + 1);
            int trackW = right - left;

            g2.setColor(new Color(24, 32, 54));
            g2.fillRoundRect(left, cy - h / 2, trackW, h, h, h);

            float frac = (animValue - min) / (float) Math.max(max - min, 1);
            int fillW = (int) (trackW * frac);
            int knobX = left + (int) (trackW * frac);

            g2.setPaint(new LinearGradientPaint(left, 0, Math.max(right, left + 1), 0,
                    new float[]{0f, 1f},
                    new Color[]{ACCENT2, ACCENT}));
            g2.setPaint(new LinearGradientPaint(left, 0, Math.max(right, left + 1), 0,
                    new float[]{0f, 1f},
                    new Color[]{ACCENT2, ACCENT}));
            g2.fillRoundRect(left, cy - h / 2, Math.max(fillW, h), h, h, h);

            if (hovered || dragging) {
                g2.setColor(new Color(ACCENT.getRed(), ACCENT.getGreen(), ACCENT.getBlue(), 40));
                g2.fillOval(knobX - 13, cy - 13, 26, 26);
            }
            g2.setColor(ACCENT2);
            g2.fillOval(knobX - 7, cy - 7, 14, 14);
            g2.setColor(Color.WHITE);
            g2.drawOval(knobX - 7, cy - 7, 14, 14);
            g2.dispose();
        }
    }

    /* ═══════════════════════════════════════════════════════════════
       SCROLL BAR + PARTICLE
       ═══════════════════════════════════════════════════════════════ */
    class ModernScrollBarUI extends javax.swing.plaf.basic.BasicScrollBarUI {
        @Override
        protected void configureScrollBarColors() {
        }

        @Override
        protected JButton createDecreaseButton(int o) {
            JButton b = new JButton();
            b.setPreferredSize(new Dimension(0, 0));
            return b;
        }

        @Override
        protected JButton createIncreaseButton(int o) {
            JButton b = new JButton();
            b.setPreferredSize(new Dimension(0, 0));
            return b;
        }

        @Override
        protected void paintThumb(Graphics g, JComponent c, Rectangle r) {
            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(new Color(147, 74, 224, 200));
            g2.fillRoundRect(r.x + 2, r.y + 2, r.width - 4, r.height - 4, 6, 6);
        }

        @Override
        protected void paintTrack(Graphics g, JComponent c, Rectangle r) {
            g.setColor(BG_DARK);
            g.fillRect(r.x, r.y, r.width, r.height);
        }
    }

    class Particle {
        float x, y, vx, vy, life;
        int size;
        Particle(int w, int h) {
            reset(w, h);
        }
        void reset(int w, int h) {
            x = (float) (Math.random() * Math.max(w, 1050));
            y = (float) (Math.random() * Math.max(h, 650));
            vx = (float) (Math.random() * 0.3 - 0.15);
            vy = (float) (Math.random() * 0.3 - 0.15);
            life = (float) (Math.random() * Math.PI * 2);
            size = (int) (Math.random() * 3 + 1);
        }
        void update() {
            x += vx;
            y += vy;
            life += 0.02f;
            if (x < -10 || x > 1120 || y < -10 || y > 700) reset(1050, 650);
        }
    }

    /* ═══════════════════════════════════════════════════════════════
       BACKEND — файлы, HWID, вход, статистика
       ═══════════════════════════════════════════════════════════════ */
    private void openDir() {
        try {
            Desktop.getDesktop().open(gameDirOrDef().toFile());
        } catch (Exception e) {
            log("Не удалось открыть папку: " + e.getMessage());
        }
    }

    private Path gameDirOrDef() {
        return new File("C:\\Horus").toPath().toAbsolutePath();
    }

    private String getCurrentHwid() {
        String raw;
        try {
            ProcessBuilder pb = new ProcessBuilder("wmic", "csproduct", "get", "uuid");
            pb.redirectErrorStream(true);
            Process p = pb.start();
            StringBuilder out = new StringBuilder();
            try (BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream(), StandardCharsets.UTF_8))) {
                String line;
                while ((line = r.readLine()) != null) {
                    if (!line.trim().isEmpty()) out.append(line.trim()).append("\n");
                }
            }
            p.waitFor();
            String[] lines = out.toString().split("\n");
            raw = lines.length > 1 ? lines[1].trim() : lines.length > 0 ? lines[0].trim() : "";
        } catch (Exception e) {
            raw = "";
        }
        if (raw.isEmpty()) {
            String cached = readLauncherConfig("hwid_fallback");
            if (cached != null && cached.length() == 32) {
                raw = cached;
            } else {
                raw = UUID.randomUUID().toString().replace("-", "");
                updateLauncherConfig("hwid_fallback", raw);
            }
        }
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] digest = md.digest(raw.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : digest) sb.append(String.format("%02x", b));
            String h = sb.toString().toUpperCase(Locale.ROOT);
            return h.substring(0, 4) + "-" + h.substring(4, 8) + "-" + h.substring(8, 12) + "-" + h.substring(12, 16);
        } catch (Exception e) {
            return "NO-HWID";
        }
    }

    private void writeAccountFile(String uid, String login) {
        writeAccountFile(uid, login, null, null);
    }

    private void writeAccountFile(String uid, String login, String roleOverride, String expiryOverride) {
        try {
            Path acc = gameDirOrDef().resolve("horus-account.json");
            String role = accountRole;
            String expiry = accountExpiry;
            String plan = accountPlan;
            if (roleOverride != null && !roleOverride.isEmpty()) role = roleOverride;
            if (expiryOverride != null && !expiryOverride.isEmpty()) expiry = expiryOverride;
            String json = "{\"uid\":\"" + jsonEscape(uid) + "\",\"login\":\"" + jsonEscape(login)
                    + "\",\"role\":\"" + jsonEscape(role) + "\",\"expiresAt\":\"" + jsonEscape(expiry)
                    + "\",\"plan\":\"" + jsonEscape(plan) + "\"}";
            Files.writeString(acc, json, StandardCharsets.UTF_8);
        } catch (Exception e) {
            log("Ошибка записи профиля аккаунта: " + e);
        }
    }

    private void doLogin() {
        if (loginBtn != null) loginBtn.setEnabled(false);
        new Thread(this::loginToSite, "auth").start();
    }

    private void loginToSite() {
        try {
            if (loginField == null || passwordField == null) return;
            String login = loginField.getText().trim();
            String password = new String(passwordField.getPassword());
            boolean emptyLogin = login.isEmpty();
            boolean emptyPw = password.isEmpty();
            SwingUtilities.invokeLater(() -> {
                if (loginErrLabel != null) {
                    loginErrLabel.setText(emptyLogin ? "Логин должен быть заполнен" : " ");
                    markFieldError(loginField, emptyLogin);
                }
                if (pwErrLabel != null) {
                    pwErrLabel.setText(emptyPw ? "Пароль должен быть заполнен" : " ");
                    markFieldError(passwordField, emptyPw);
                }
                if (emptyLogin || emptyPw) {
                    authStatusLabel.setText(emptyLogin && emptyPw
                            ? "<html><font color='#e11d48'>Заполните все поля</font></html>"
                            : "<html><font color='#e11d48'>Введите недостающие данные</font></html>");
                }
            });
            if (emptyLogin || emptyPw) {
                log("Поля входа должны быть заполнены.");
                return;
            }
            String body = "{\"login\":" + JsonValue.escape(login) + ",\"password\":" + JsonValue.escape(password) + "}";
            HttpRequest req = HttpRequest.newBuilder(URI.create(SITE_API + "/api/login"))
                    .timeout(Duration.ofSeconds(30))
                    .header("Content-Type", "application/json; charset=utf-8")
                    .header("User-Agent", "HorusLauncher/1.0")
                    .POST(HttpRequest.BodyPublishers.ofString(body, StandardCharsets.UTF_8))
                    .build();
            HttpResponse<String> resp = http.send(req, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
            JsonObject parsed = parseJsonSafe(resp.body());
            if (resp.statusCode() / 100 != 2) {
                String msg = parsed != null && parsed.has("error") ? parsed.getString("error") : "Сервер: HTTP " + resp.statusCode();
                throw new IOException(msg);
            }
            if (parsed == null || !"true".equals(parsed.get("ok").raw())) {
                String msg = parsed != null && parsed.has("error") ? parsed.getString("error") : "Ошибка входа";
                throw new IOException(msg);
            }
            // 2FA: сервер запросил код из Telegram
            if (parsed.has("need2fa") && "true".equals(parsed.get("need2fa").raw()) && parsed.has("token")) {
                String faToken = parsed.getString("token");
                String code = javax.swing.JOptionPane.showInputDialog(null,
                        "<html><body style='width:250px'>На аккаунте включена 2FA.<br>Введите код из Telegram (6 цифр):</body></html>",
                        "Двухфакторная аутентификация", javax.swing.JOptionPane.PLAIN_MESSAGE);
                if (code == null || code.trim().isEmpty()) { log("Вход отменён."); return; }
                String body2 = "{\"token\":" + JsonValue.escape(faToken) + ",\"code\":" + JsonValue.escape(code.trim()) + "}";
                HttpRequest req2 = HttpRequest.newBuilder(URI.create(SITE_API + "/api/login/2fa"))
                        .timeout(Duration.ofSeconds(30))
                        .header("Content-Type", "application/json; charset=utf-8")
                        .header("User-Agent", "HorusLauncher/1.0")
                        .POST(HttpRequest.BodyPublishers.ofString(body2, StandardCharsets.UTF_8))
                        .build();
                HttpResponse<String> resp2 = http.send(req2, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
                parsed = parseJsonSafe(resp2.body());
                if (resp2.statusCode() / 100 != 2 || parsed == null || !"true".equals(parsed.get("ok").raw())) {
                    String m2 = parsed != null && parsed.has("error") ? parsed.getString("error") : "Ошибка проверки кода";
                    throw new IOException(m2);
                }
                resp = resp2;
            }
            JsonObject user = parsed.get("user").asObject();
            String token = extractSessionCookie(resp);
            applyUserProfile(user, token, "Вход выполнен: ");
        } catch (Exception e) {
            log("Ошибка входа: " + e.getMessage());
            SwingUtilities.invokeLater(() -> {
                if (authStatusLabel != null) {
                    authStatusLabel.setText("<html><font color='#e11d48'>Неверные данные: "
                            + (e.getMessage() == null ? "ошибка" : e.getMessage().replace("<", "&lt;").replace(">", "&gt;"))
                            + "</font></html>");
                }
                if (pwErrLabel != null) {
                    pwErrLabel.setText("Проверьте логин и пароль");
                    markFieldError(passwordField, true);
                }
            });
        } finally {
            SwingUtilities.invokeLater(() -> {
                if (loginBtn != null) loginBtn.setEnabled(true);
            });
        }
    }

    private void doLogout() {
        updateLauncherConfig("session", null);
        SwingUtilities.invokeLater(() -> {
            accountLogin = "";
            accountUid = "";
            accountRole = "Пользователь";
            accountExpiry = "—";
            accountPlan = "";
            if (loginField != null) loginField.setText("");
            if (passwordField != null) passwordField.setText("");
            if (authStatusLabel != null) authStatusLabel.setText("");
            if (loginErrLabel != null) loginErrLabel.setText(" ");
            if (pwErrLabel != null) pwErrLabel.setText(" ");
            if (loginField != null) markFieldError(loginField, false);
            if (passwordField != null) markFieldError(passwordField, false);
            if (welcomeLabel != null) welcomeLabel.setText(" ");
            cardsLayout.show(cardsPanel, "login");
            titleLabel.setText("Вход");
        });
        log("Вы вышли из аккаунта");
        showToast("Вы вышли из аккаунта");
    }

    private void applyUserProfile(JsonObject user, String token, String okPrefix) {
        if (user == null) return;
        String uid = user.has("uid") ? user.getString("uid") : "";
        String login = user.has("login") ? user.getString("login") : "";
        String role = "Пользователь";
        String expiry = "—";
        String plan = "";
        JsonValue sub = user.get("subscription");
        if (sub instanceof JsonObject so && "active".equals(so.getString("status"))) {
            plan = so.has("plan") && so.getString("plan") != null ? so.getString("plan") : "";
            String planName = so.has("name") ? so.getString("name") : "Подписка";
            if (planName.startsWith("HorusClient ")) planName = planName.substring("HorusClient ".length());
            role = "active".equals(so.getString("status")) ? planName : "Пользователь";
            expiry = "true".equals(so.getString("forever"))
                    ? "Навсегда"
                    : (so.has("expiresAt") && so.getString("expiresAt") != null ? so.getString("expiresAt") : "—");
        }
        accountUid = uid;
        accountLogin = login;
        accountRole = role;
        accountExpiry = expiry;
        accountPlan = plan;
        final String fLogin = login;
        SwingUtilities.invokeLater(() -> {
            if (loginField != null) loginField.setText(fLogin);
            if (passwordField != null) passwordField.setText("");
            if (authStatusLabel != null) authStatusLabel.setText((fLogin.isEmpty() ? "Аккаунт" : fLogin) + " · " + accountRole);
            if (welcomeLabel != null) welcomeLabel.setText("Привет, " + (fLogin.isEmpty() ? "аккаунт" : fLogin) + "!");
            cardsLayout.show(cardsPanel, "main");
            showView("home");
        });
        if (token != null && !token.isEmpty()) updateLauncherConfig("session", token);
        if (!uid.isEmpty()) updateLauncherConfig("uid", uid);
        if (!login.isEmpty()) updateLauncherConfig("username", login);
        updateLauncherConfig("role", role);
        updateLauncherConfig("plan", plan);
        writeAccountFile(uid.isEmpty() ? "None" : uid, login, role, expiry);
        bindHwidIfNeeded();
        log(okPrefix + (login.isEmpty() ? "аккаунт" : login));
    }

    private void applySavedSession() {
        String token = readSessionCookie();
        if (token == null || token.isEmpty()) return;
        new Thread(() -> {
            try {
                HttpRequest req = HttpRequest.newBuilder(URI.create(SITE_API + "/api/me"))
                        .timeout(Duration.ofSeconds(30))
                        .header("Cookie", "hs_session=" + token)
                        .header("User-Agent", "HorusLauncher/1.0")
                        .GET().build();
                HttpResponse<String> resp = http.send(req, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
                if (resp.statusCode() / 100 != 2) return;
                JsonObject body = parseJsonSafe(resp.body());
                if (body == null || !"true".equals(body.get("authed").raw())) {
                    log("Сессия истекла — войдите заново.");
                    return;
                }
                applyUserProfile(body.get("user").asObject(), null, "Сессия восстановлена: ");
            } catch (Exception e) {
                log("Не удалось восстановить сессию: " + e.getMessage());
            }
        }, "session-restore").start();
    }

    private void bindHwidIfNeeded() {
        String token = readSessionCookie();
        if (token == null || token.isEmpty()) return;
        new Thread(() -> {
            try {
                HttpRequest req = HttpRequest.newBuilder(URI.create(SITE_API + "/api/me"))
                        .timeout(Duration.ofSeconds(25))
                        .header("Cookie", "hs_session=" + token)
                        .header("User-Agent", "HorusLauncher/1.0")
                        .GET().build();
                HttpResponse<String> resp = http.send(req, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
                JsonObject body = parseJsonSafe(resp.body());
                if (body == null || !"true".equals(body.get("authed").raw())) return;
                JsonObject user = body.get("user").asObject();
                String dbHwid = user.has("hwid") && user.getString("hwid") != null ? user.getString("hwid").trim() : "";
                String myHwid = getCurrentHwid();
                if (dbHwid.isEmpty()) {
                    sendBind(myHwid);
                } else if (!dbHwid.equals(myHwid)) {
                    showToast("HWID привязан к другому ПК! Сбросьте привязку в кабинете.");
                    log("HWID: привязан к другому ПК. Сбросьте привязку в кабинете, чтобы играть здесь.");
                }
            } catch (Exception e) {
                log("HWID: не удалось проверить привязку: " + e.getMessage());
            }
        }, "hwid-bind").start();
    }

    private void sendBind(String hwid) {
        try {
            String token = readSessionCookie();
            if (token == null) return;
            String body = "{\"hwid\":" + JsonValue.escape(hwid) + "}";
            HttpRequest req = HttpRequest.newBuilder(URI.create(SITE_API + "/api/hwid/bind"))
                    .timeout(Duration.ofSeconds(25))
                    .header("Content-Type", "application/json; charset=utf-8")
                    .header("Cookie", "hs_session=" + token)
                    .header("User-Agent", "HorusLauncher/1.0")
                    .POST(HttpRequest.BodyPublishers.ofString(body, StandardCharsets.UTF_8))
                    .build();
            HttpResponse<String> resp = http.send(req, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
            if (resp.statusCode() / 100 == 2) {
                log("HWID: успешно привязан");
            } else {
                String err = "код " + resp.statusCode();
                JsonObject parsed = parseJsonSafe(resp.body());
                if (parsed != null && parsed.has("error")) err = parsed.getString("error");
                log("HWID: " + err);
                showToast("HWID: " + err);
            }
        } catch (Exception e) {
            log("HWID: привязка не удалась: " + e.getMessage());
        }
    }

    private JsonObject parseJsonSafe(String s) {
        try {
            if (s == null || s.isEmpty()) return null;
            JsonValue v = Json.parse(s);
            return v instanceof JsonObject ? (JsonObject) v : null;
        } catch (Exception e) {
            return null;
        }
    }

    private String extractSessionCookie(HttpResponse<String> resp) {
        for (String h : resp.headers().map().getOrDefault("set-cookie", List.of())) {
            if (h == null) continue;
            String s = h.trim();
            if (s.startsWith("hs_session=")) {
                int end = s.indexOf(';');
                return end > 0 ? s.substring("hs_session=".length(), end) : s.substring("hs_session=".length());
            }
        }
        return null;
    }

    private String readSessionCookie() {
        try {
            Path cfg = gameDirOrDef().resolve("launcher_config.json");
            if (Files.exists(cfg)) {
                JsonObject c = Json.parse(Files.readString(cfg, StandardCharsets.UTF_8)).asObject();
                if (c != null && c.has("session") && c.get("session").raw() != null && !c.getString("session").isEmpty()) {
                    return c.getString("session");
                }
            }
        } catch (Exception ignored) {
        }
        return null;
    }

    private boolean hasActiveSubscription() {
        String token = readSessionCookie();
        if (token == null || token.isEmpty()) {
            log("Доступ: нет сохранённой сессии. Войдите в аккаунт.");
            return false;
        }
        try {
            HttpRequest req = HttpRequest.newBuilder(URI.create(SITE_API + "/api/me"))
                    .timeout(Duration.ofSeconds(20))
                    .header("Cookie", "hs_session=" + token)
                    .header("User-Agent", "HorusLauncher/1.0")
                    .GET().build();
            HttpResponse<String> resp = http.send(req, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
            if (resp.statusCode() / 100 != 2) {
                log("Доступ: сервер ответил HTTP " + resp.statusCode());
                return false;
            }
            JsonObject body = parseJsonSafe(resp.body());
            if (body == null || !"true".equals(body.get("authed").raw())) {
                log("Доступ: сессия истекла. Войдите в аккаунт заново.");
                return false;
            }
            JsonValue sub = body.get("user").asObject().get("subscription");
            if (sub instanceof JsonObject so) {
                String status = so.getString("status");
                if ("active".equals(status)) return true;
                log("Доступ: статус подписки \"" + status + "\". Запуск недоступен.");
                return false;
            }
            log("Доступ: подписка не найдена.");
            return false;
        } catch (Exception e) {
            log("Доступ: не удалось проверить подписку: " + e.getMessage());
            return false;
        }
    }

    private String readLauncherConfig(String key) {
        try {
            Path cfg = gameDirOrDef().resolve("launcher_config.json");
            if (Files.exists(cfg)) {
                JsonObject c = Json.parse(Files.readString(cfg, StandardCharsets.UTF_8)).asObject();
                if (c != null && c.has(key) && c.get(key).raw() != null && !c.getString(key).isEmpty()) {
                    return c.getString(key);
                }
            }
        } catch (Exception ignored) {
        }
        return null;
    }

    private void updateLauncherConfig(String key, String value) {
        try {
            Path cfg = gameDirOrDef().resolve("launcher_config.json");
            JsonObject c;
            try {
                c = Files.exists(cfg) ? Json.parse(Files.readString(cfg, StandardCharsets.UTF_8)).asObject() : null;
            } catch (Exception ignored) {
                c = null;
            }
            if (c == null) c = new JsonObject();
            c.members.put(key, value == null ? JsonValue.NULL : JsonValue.str(value));
            Files.createDirectories(cfg.getParent());
            Files.writeString(cfg, c.toJson(), StandardCharsets.UTF_8);
        } catch (Exception ignored) {
        }
    }

    private String jsonEscape(String s) {
        return s.replace("\\", "\\\\").replace("\"", "\\\"");
    }

    private void setProgress(int v) {
        SwingUtilities.invokeLater(() -> progressBar.setValue(v));
    }

    /* ═══════════════════════════════════════════════════════════════
       СТАТИСТИКА ИГРЫ
       ═══════════════════════════════════════════════════════════════ */
    private Path statsFile() {
        return gameDirOrDef().resolve("launcher_stats.json");
    }

    private JsonObject loadStats() {
        try {
            if (Files.exists(statsFile())) {
                JsonValue v = Json.parse(Files.readString(statsFile(), StandardCharsets.UTF_8));
                if (v instanceof JsonObject o && o.has("total_seconds")) return o;
            }
        } catch (Exception ignored) {
        }
        JsonObject o = new JsonObject();
        o.members.put("total_seconds", JsonValue.num("0"));
        JsonObject srv = new JsonObject();
        o.members.put("servers", srv);
        return o;
    }

    private void saveStats(JsonObject data) {
        try {
            Files.writeString(statsFile(), data.toJson(), StandardCharsets.UTF_8);
        } catch (Exception ignored) {
        }
    }

    private void addSeconds(long seconds) {
        JsonObject st = loadStats();
        long total = Math.round(Double.parseDouble(st.get("total_seconds").raw()));
        total += seconds;
        st.members.put("total_seconds", JsonValue.num(String.valueOf(total)));
        saveStats(st);
    }

    private void syncServersFromLogs() {
        try {
            Path log = gameDirOrDef().resolve("logs/latest.log");
            if (!Files.exists(log)) return;
            String content = Files.readString(log, StandardCharsets.UTF_8);
            Matcher m = Pattern.compile("Connecting to ([\\w.-]+)").matcher(content);
            Set<String> found = new LinkedHashSet<>();
            while (m.find()) found.add(m.group(1));
            if (found.isEmpty()) return;
            JsonObject st = loadStats();
            JsonObject srv = st.get("servers") instanceof JsonObject inside ? inside : new JsonObject();
            for (String s : found) {
                int cnt = srv.has(s) ? (int) Math.round(Double.parseDouble(srv.getString(s).replace("\"", ""))) : 0;
                srv.members.put(s, JsonValue.num(String.valueOf(cnt + 1)));
            }
            st.members.put("servers", srv);
            saveStats(st);
        } catch (Exception ignored) {
        }
    }

    private String topServersText(JsonObject st) {
        JsonObject srv = st.get("servers") instanceof JsonObject inside ? inside : null;
        if (srv == null || srv.members.isEmpty()) return "";
        List<Map.Entry<String, Long>> list = new ArrayList<>();
        for (Map.Entry<String, JsonValue> e : srv.members.entrySet()) {
            try {
                list.add(Map.entry(e.getKey(), Math.round(Double.parseDouble(e.getValue().raw()))));
            } catch (Exception ignored) {
            }
        }
        list.sort((a, b) -> Long.compare(b.getValue(), a.getValue()));
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < Math.min(5, list.size()); i++) {
            if (i > 0) sb.append(", ");
            sb.append(list.get(i).getKey()).append(" (").append(list.get(i).getValue()).append(")");
        }
        return sb.toString();
    }

    /* ═══════════════════════════════════════════════════════════════
       ЗАПУСК ИГРЫ (как в python-лаунчере)
       ═══════════════════════════════════════════════════════════════ */
    private void doLaunch() {
        if (isLaunching) return;
        if (accountUid.isEmpty()) {
            showToast("Войдите в аккаунт");
            log("Сначала войдите в аккаунт на сайте.");
            return;
        }
        isLaunching = true;
        SwingUtilities.invokeLater(() -> {
            launchBtn.setEnabled(false);
            progressBar.setValue(0);
        });
        new Thread(() -> {
            try {
                Path mods = gameDir.resolve("mods");
                Files.createDirectories(mods);

                log("Проверка доступа...");

                if (!hasActiveSubscription()) {
                    throw new IOException("Подписка заморожена или неактивна. Запуск недоступен. Обратитесь в поддержку.");
                }

                log("Завершаю старые java-процессы...");
                killOldJava();

                Path clientJar = mods.resolve("horus-1.21.4.jar");
                if (!Files.exists(clientJar) || Files.size(clientJar) == 0) {
                    log("Загрузка клиента: " + VERSION_HORUS);
                    showDownload("Загрузка: 0%");
                    downloadWithProgress(CLIENT_URL_HORUS, clientJar);
                    log("Клиент установлен.");
                } else {
                    log("Клиент уже скачан.");
                }

                try {
                    Path modsDir = mods;
                    try (var s = Files.list(modsDir)) {
                        boolean hasApi = s.anyMatch(f -> f.getFileName().toString().toLowerCase(Locale.ROOT).startsWith("fabric-api"));
                        if (!hasApi) {
                            log("Загрузка Fabric API...");
                            showDownload("Загрузка Fabric API...");
                            downloadFabricApi();
                        }
                    }
                } catch (Exception ea) {
                    log("Fabric API: " + ea.getMessage());
                }

                if (!isFabricInstalled()) {
                    log("Установка Fabric Loader " + LOADER_VERSION + "...");
                    showDownload("Установка Fabric Loader...");
                    installFabricLoader();
                }

                log("Подготовка клиента Minecraft...");
                Path mcJsonPath = ensureMinecraftClient();
                JsonObject loader = Json.parse(Files.readString(
                        gameDir.resolve("versions").resolve(LOADER_VERSION_ID).resolve(LOADER_VERSION_ID + ".json"),
                        StandardCharsets.UTF_8)).asObject();
                JsonObject mc = Json.parse(Files.readString(mcJsonPath, StandardCharsets.UTF_8)).asObject();

                String mainClass = loader.has("mainClass") ? loader.getString("mainClass") : "net.fabricmc.loader.impl.launch.knot.KnotClient";

                LinkedHashMap<String, String> libMap = new LinkedHashMap<>();
                if (mc.has("libraries")) for (JsonValue v : mc.getArray("libraries").values) addLibToClasspath(v.asObject(), libMap);
                if (loader.has("libraries")) for (JsonValue v : loader.getArray("libraries").values) addLibToClasspath(v.asObject(), libMap);
                List<String> cp = new ArrayList<>(libMap.values());
                cp.add(gameDir.resolve("versions").resolve(MC_VERSION).resolve(MC_VERSION + ".jar").toString());
                String classpath = String.join(File.pathSeparator, new LinkedHashSet<>(cp));

                Path natives = extractNatives(mc);
                String assetId = mc.get("assetIndex").asObject().getString("id");
                ensureAssets(mc.get("assetIndex").asObject().getString("url"), assetId);

                setGuiScale2();

                String login = accountLogin.isEmpty() ? System.getProperty("user.name", "Player") : accountLogin;
                String uidRaw = accountUid;
                if (uidRaw == null || uidRaw.isEmpty()) uidRaw = readLauncherConfig("uid");
                if (uidRaw == null) uidRaw = "None";
                String uidStr = uidRaw.replace("-", "");
                boolean uidValid = uidStr.length() == 32 && uidStr.matches("[0-9a-fA-F]+");
                if (!uidValid) uidStr = UUID.randomUUID().toString().replace("-", "");
                writeAccountFile("None".equals(uidRaw) ? "None" : uidRaw, login);

                List<String> launch = new ArrayList<>();
                launch.add(findJava());
                launch.add("-Xmx" + ramGb + "G");
                launch.add("-XX:+UseG1GC");
                launch.add("-Djava.library.path=" + natives);
                launch.add("-cp");
                launch.add(classpath);
                launch.add(mainClass);
                launch.add("--assetsDir");
                launch.add(gameDir.resolve("assets").toString());
                launch.add("--assetIndex");
                launch.add(assetId);
                launch.add("--version");
                launch.add(LOADER_VERSION_ID);
                launch.add("--gameDir");
                launch.add(gameDir.toString());
                launch.add("--username");
                launch.add(login);
                launch.add("--uuid");
                launch.add(uidStr);
                launch.add("--accessToken");
                launch.add("0");
                launch.add("--userType");
                launch.add("legacy");

                log("Запуск Minecraft...");
                hideDownload();
                setProgress(100);
                ProcessBuilder pb = new ProcessBuilder(launch).directory(gameDir.toFile()).redirectErrorStream(true);
                Process p;
                try {
                    p = pb.start();
                } catch (Exception e) {
                    throw new IOException("Не удалось запустить java: " + e.getMessage(), e);
                }
                SwingUtilities.invokeLater(() -> frame.setVisible(false));
                sessionStartedAt = System.currentTimeMillis();
                new Thread(() -> {
                    try (BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream(), StandardCharsets.UTF_8))) {
                        String line;
                        while ((line = r.readLine()) != null) {
                            if (!line.trim().isEmpty()) log(line);
                        }
                    } catch (Exception ignored) {
                    }
                    int code;
                    try {
                        code = p.waitFor();
                    } catch (InterruptedException e) {
                        code = -1;
                    }
                    long durSec = (System.currentTimeMillis() - sessionStartedAt) / 1000;
                    addSeconds(durSec);
                    syncServersFromLogs();
                    isLaunching = false;
                    log("Minecraft завершён (код " + code + ").");
                    SwingUtilities.invokeLater(() -> {
                        launchBtn.setEnabled(true);
                        progressBar.setValue(0);
                        frame.setVisible(true);
                        frame.toFront();
                        showView("home");
                    });
                }, "minecraft-watch").start();
            } catch (Exception ex) {
                isLaunching = false;
                log("ОШИБКА: " + ex);
                hideDownload();
                SwingUtilities.invokeLater(() -> {
                    launchBtn.setEnabled(true);
                    progressBar.setValue(0);
                    frame.setVisible(true);
                });
                showToast("Ошибка запуска: " + ex.getMessage());
            }
        }, "launch-worker").start();
    }

    private void killOldJava() {
        long self = ProcessHandle.current().pid();
        try {
            ProcessHandle.allProcesses().forEach(ph -> {
                if (ph.pid() == self) return;
                java.util.Optional<String> cmd = ph.info().command();
                String c = cmd.orElse("");
                boolean isJava = c.toLowerCase(Locale.ROOT).endsWith("java.exe") || c.toLowerCase(Locale.ROOT).endsWith("javaw.exe")
                        || c.toLowerCase(Locale.ROOT).endsWith("java");
                if (isJava) {
                    try {
                        ph.destroy();
                    } catch (Exception ignored) {
                    }
                }
            });
            Thread.sleep(1000);
        } catch (Exception ignored) {
        }
    }

    private boolean isFabricInstalled() {
        return Files.exists(gameDir.resolve("versions").resolve(LOADER_VERSION_ID).resolve(LOADER_VERSION_ID + ".json"));
    }

    private void installFabricLoader() throws Exception {
        Files.createDirectories(gameDir);
        Path installer = appDir.resolve("fabric-installer-" + INSTALLER_VERSION + ".jar");
        if (!Files.exists(installer)) {
            log("Скачиваю fabric-installer...");
            download(INSTALLER_URL, installer);
        }
        runProcess(findJava(), "-jar", installer.toString(), "client", "-mcversion", MC_VERSION,
                "-loader", LOADER_VERSION, "-dir", gameDir.toString(), "-noprofile");
        Path json = gameDir.resolve("versions").resolve(LOADER_VERSION_ID).resolve(LOADER_VERSION_ID + ".json");
        if (!Files.exists(json)) throw new IOException("Профиль Fabric не создан");
        log("Fabric Loader установлен.");
    }

    private void downloadFabricApi() throws Exception {
        String json = downloadString(FABRIC_API_QUERY);
        JsonArray list = Json.parse(json).asArray();
        if (list.isEmpty()) throw new IOException("Fabric API не найден");
        JsonObject file = list.get(0).asObject().getArray("files").get(0).asObject();
        String filename = file.has("filename") ? file.getString("filename") : "fabric-api.jar";
        download(file.getString("url"), gameDir.resolve("mods").resolve(filename));
    }

    private void setGuiScale2() {
        try {
            Path opts = gameDir.resolve("options.txt");
            boolean found = false;
            StringBuilder sb = new StringBuilder();
            if (Files.exists(opts)) {
                for (String line : Files.readAllLines(opts, StandardCharsets.UTF_8)) {
                    if (line.startsWith("guiScale:")) {
                        sb.append("guiScale:2\n");
                        found = true;
                    } else {
                        sb.append(line).append("\n");
                    }
                }
            }
            if (!found) sb.append("guiScale:2\n");
            Files.writeString(opts, sb.toString(), StandardCharsets.UTF_8);
        } catch (Exception ignored) {
        }
    }

    /* ═══════════════════════════════════════════════════════════════
       СКАЧИВАНИЕ
       ═══════════════════════════════════════════════════════════════ */
    private void downloadWithProgress(String url, Path target) throws Exception {
        HttpRequest req = HttpRequest.newBuilder(URI.create(url)).header("User-Agent", "HorusLauncher/1.0").GET().build();
        HttpResponse<InputStream> resp = http.send(req, HttpResponse.BodyHandlers.ofInputStream());
        if (resp.statusCode() / 100 != 2) {
            resp.body().close();
            throw new IOException("HTTP " + resp.statusCode());
        }
        long total = resp.headers().firstValueAsLong("Content-Length").orElse(-1);
        Path part = target.resolveSibling(target.getFileName() + ".part");
        Files.createDirectories(part.getParent());
        long done = 0;
        long startMs = System.currentTimeMillis();
        int lastPct = -1;
        try (InputStream in = resp.body(); OutputStream out = Files.newOutputStream(part)) {
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) != -1) {
                out.write(buf, 0, n);
                done += n;
                if (total > 0) {
                    final int pct = (int) (done * 100 / total);
                    if (pct != lastPct) {
                        lastPct = pct;
                        long sec = Math.max(1, (System.currentTimeMillis() - startMs) / 1000);
                        double mbps = (done / 1048576.0) / sec;
                        final String pctText = String.format("Загрузка: %d%% (%.1f МБ/с)", pct, mbps);
                        SwingUtilities.invokeLater(() -> {
                            dlLabel.setText(pctText);
                            progressBar.setValue(pct);
                        });
                    }
                }
            }
        } catch (Exception e) {
            try {
                Files.deleteIfExists(part);
            } catch (Exception ignore) {
            }
            throw e;
        }
        Files.move(part, target, StandardCopyOption.REPLACE_EXISTING);
    }

    private void download(String url, Path target) throws Exception {
        HttpRequest req = HttpRequest.newBuilder(URI.create(url)).GET().build();
        HttpResponse<InputStream> resp = http.send(req, HttpResponse.BodyHandlers.ofInputStream());
        if (resp.statusCode() / 100 != 2) {
            resp.body().close();
            throw new IOException("HTTP " + resp.statusCode());
        }
        long total = resp.headers().firstValueAsLong("Content-Length").orElse(-1);
        Path part = target.resolveSibling(target.getFileName() + ".part");
        Files.createDirectories(part.getParent());
        long done = 0;
        int lastLog = -1;
        try (InputStream in = resp.body(); OutputStream out = Files.newOutputStream(part)) {
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) != -1) {
                out.write(buf, 0, n);
                done += n;
                if (total > 8_000_000) {
                    int pct = (int) (done * 100 / total);
                    if (pct / 10 != lastLog) {
                        lastLog = pct / 10;
                        log(target.getFileName() + ": " + (pct / 10 * 10) + "%");
                    }
                }
            }
        } catch (Exception e) {
            try {
                Files.deleteIfExists(part);
            } catch (Exception ignore) {
            }
            throw e;
        }
        Files.move(part, target, StandardCopyOption.REPLACE_EXISTING);
    }

    private String downloadString(String url) throws Exception {
        HttpRequest req = HttpRequest.newBuilder(URI.create(url)).GET().build();
        HttpResponse<String> resp = http.send(req, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
        if (resp.statusCode() / 100 != 2) throw new IOException("HTTP " + resp.statusCode());
        return resp.body();
    }

    private void runProcess(String... cmd) throws Exception {
        ProcessBuilder pb = new ProcessBuilder(cmd);
        pb.redirectErrorStream(true);
        Process p = pb.start();
        StringBuilder out = new StringBuilder();
        try (BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream(), StandardCharsets.UTF_8))) {
            String line;
            while ((line = r.readLine()) != null) {
                if (!line.trim().isEmpty()) {
                    log(line);
                    out.append(line).append('\n');
                }
            }
        }
        int code = p.waitFor();
        if (code != 0) {
            throw new IOException("процесс завершился с кодом " + code + (out.length() > 0 ? ":\n" + out : "."));
        }
    }

    private String findJava() {
        Path exe = Path.of(System.getProperty("java.home"), "bin", "java.exe");
        return Files.exists(exe) ? exe.toString() : "java";
    }

    private void addLibToClasspath(JsonObject lib, LinkedHashMap<String, String> libMap) {
        if (lib.has("rules") && !rulesAllowed(lib)) return;
        String name = lib.has("name") ? lib.getString("name") : null;
        if (name != null && name.contains(":natives-")) return;
        String key = name != null && name.contains(":") ? name.split(":")[0] + ":" + name.split(":")[1] : null;
        if (lib.has("downloads")) {
            JsonObject dl = lib.get("downloads").asObject();
            if (dl.has("artifact")) {
                JsonObject art = dl.get("artifact").asObject();
                Path target = gameDir.resolve("libraries").resolve(art.getString("path"));
                if (!Files.exists(target)) hwm_download(art, target);
                if (key != null) libMap.put(key, target.toString());
                else libMap.put(target.toString(), target.toString());
            }
        } else if (name != null) {
            Path target = gameDir.resolve("libraries").resolve(mavenPath(name));
            if (!Files.exists(target)) {
                try {
                    download("https://maven.fabricmc.net/" + mavenPath(name), target);
                } catch (Exception e) {
                    log("Ошибка: " + target.getFileName() + " — " + e.getClass().getSimpleName() + ": " + e.getMessage());
                }
            }
            if (key != null) libMap.put(key, target.toString());
            else libMap.put(target.toString(), target.toString());
        }
    }

    private void hwm_download(JsonObject art, Path target) {
        try {
            download(art.getString("url"), target);
        } catch (Exception e) {
            log("Ошибка: " + target.getFileName() + " — " + (art.getString("url") == null ? "нет URL" : e.getMessage()));
        }
    }

    private Path ensureMinecraftClient() throws Exception {
        Path mcJson = gameDir.resolve("versions").resolve(MC_VERSION).resolve(MC_VERSION + ".json");
        Path mcJar = gameDir.resolve("versions").resolve(MC_VERSION).resolve(MC_VERSION + ".jar");
        if (Files.exists(mcJson) && Files.exists(mcJar) && Files.size(mcJar) > 100000) {
            try {
                JsonObject cached = Json.parse(Files.readString(mcJson, StandardCharsets.UTF_8)).asObject();
                if (cached != null && cached.has("downloads")) return mcJson;
            } catch (Exception ignore) {
            }
            log("Кэш клиента повреждён, перекачиваю...");
        }
        log("Скачиваю Minecraft " + MC_VERSION + "...");
        JsonObject manifest = Json.parse(downloadString(VERSION_MANIFEST)).asObject();
        String mcUrl = null;
        for (JsonValue v : manifest.getArray("versions").values) {
            JsonObject vo = v.asObject();
            if (MC_VERSION.equals(vo.getString("id"))) {
                mcUrl = vo.getString("url");
                break;
            }
        }
        if (mcUrl == null) throw new IOException("Версия не найдена");
        JsonObject mcVersion = Json.parse(downloadString(mcUrl)).asObject();
        Files.createDirectories(mcJson.getParent());
        Files.writeString(mcJson, mcVersion.toString(), StandardCharsets.UTF_8);
        String jarUrl = mcVersion.has("downloads") && mcVersion.get("downloads").asObject().has("client")
                ? mcVersion.get("downloads").asObject().get("client").asObject().getString("url") : null;
        if (jarUrl == null) throw new IOException("Нет ссылки на jar");
        download(jarUrl, mcJar);
        return mcJson;
    }

    private boolean rulesAllowed(JsonObject lib) {
        JsonArray rules = lib.getArray("rules");
        String osKey = System.getProperty("os.name").toLowerCase(Locale.ROOT);
        osKey = osKey.contains("win") ? "windows" : osKey.contains("mac") ? "osx" : "linux";
        boolean allow = true;
        for (JsonValue rv : rules.values) {
            JsonObject rule = rv.asObject();
            boolean actionAllow = "allow".equals(rule.getString("action"));
            boolean match = true;
            if (rule.has("os")) {
                JsonObject os = rule.get("os").asObject();
                if (os.has("name")) match = osKey.equals(os.getString("name"));
            }
            if (match) allow = actionAllow;
        }
        return allow;
    }

    private Path extractNatives(JsonObject mc) throws Exception {
        Path natives = gameDir.resolve("bin/natives-" + LOADER_VERSION_ID);
        deleteRecursive(natives);
        Files.createDirectories(natives);
        String os = System.getProperty("os.name").toLowerCase(Locale.ROOT);
        String arch = System.getProperty("os.arch").toLowerCase(Locale.ROOT);
        String osName = os.contains("win") ? "windows" : os.contains("mac") ? "macos" : "linux";
        String nsArch = arch.contains("arm") || arch.contains("aarch") ? "arm64" : (arch.contains("86") && !arch.contains("64") ? "x86" : "x86_64");
        List<String> want = new ArrayList<>();
        want.add("natives-" + osName);
        want.add("natives-" + osName + "-" + nsArch);
        for (JsonValue v : mc.getArray("libraries").values) {
            JsonObject lib = v.asObject();
            if (lib.has("rules") && !rulesAllowed(lib)) continue;
            JsonObject dl = lib.has("downloads") ? lib.get("downloads").asObject() : null;
            if (dl == null) continue;
            JsonObject nativeArt = null;
            if (dl.has("classifiers")) {
                JsonObject classifiers = dl.get("classifiers").asObject();
                for (String w : want) {
                    if (classifiers.has(w)) {
                        nativeArt = classifiers.get(w).asObject();
                        break;
                    }
                }
            } else if (lib.has("name") && dl.has("artifact")) {
                String nm = lib.getString("name");
                boolean isNative = false;
                for (String w : want) {
                    if (nm.endsWith(":" + w)) {
                        isNative = true;
                        break;
                    }
                }
                if (isNative) nativeArt = dl.get("artifact").asObject();
            }
            if (nativeArt == null) continue;
            Path jar = gameDir.resolve("libraries").resolve(nativeArt.getString("path"));
            if (!Files.exists(jar)) hwm_download(nativeArt, jar);
            if (Files.exists(jar) && Files.size(jar) > 0) unzip(jar, natives);
        }
        return natives;
    }

    private void ensureAssets(String indexUrl, String id) throws Exception {
        Path indexFile = gameDir.resolve("assets/indexes").resolve(id + ".json");
        Files.createDirectories(indexFile.getParent());
        JsonObject index = null;
        if (Files.exists(indexFile)) {
            try {
                index = Json.parse(Files.readString(indexFile, StandardCharsets.UTF_8)).asObject();
            } catch (Exception ignore) {
            }
        }
        if (index == null || !index.has("objects")) {
            log("Скачиваю индекс ресурсов...");
            index = Json.parse(downloadString(indexUrl)).asObject();
            Files.createDirectories(indexFile.getParent());
            Files.writeString(indexFile, index.toString(), StandardCharsets.UTF_8);
        }
        Path objectsDir = gameDir.resolve("assets/objects");
        Files.createDirectories(objectsDir);
        List<JsonValue> entries = index.get("objects").asObject().values();
        AtomicLong fails = new AtomicLong();
        AtomicLong doneCount = new AtomicLong();
        long needLong = entries.stream().filter(e -> !Files.exists(objectsDir
                .resolve(e.asObject().getString("hash").substring(0, 2))
                .resolve(e.asObject().getString("hash")))).count();
        int need = (int) Math.min(needLong, Integer.MAX_VALUE);
        log("Ресурсы: " + entries.size() + " файлов (скачать: " + need + ")...");
        entries.parallelStream().forEach(e -> {
            String hash = e.asObject().getString("hash");
            Path target = objectsDir.resolve(hash.substring(0, 2)).resolve(hash);
            if (Files.exists(target)) return;
            try {
                download("https://resources.download.minecraft.net/" + hash.substring(0, 2) + "/" + hash, target);
            } catch (Exception ex) {
                fails.incrementAndGet();
            }
            long dn = doneCount.incrementAndGet();
            if (dn % Math.max(1, need / 15) == 0 || dn == need) {
                log("Ресурсы: скачано " + dn + " из " + need + " (ошибок: " + fails.get() + ")");
            }
        });
        log("Ресурсы готовы (ошибок: " + fails.get() + ")");
    }

    private void unzip(Path zip, Path outDir) throws IOException {
        try (ZipInputStream zis = new ZipInputStream(new FileInputStream(zip.toFile()))) {
            ZipEntry entry;
            byte[] buf = new byte[8192];
            while ((entry = zis.getNextEntry()) != null) {
                if (entry.isDirectory()) continue;
                Path target = outDir.resolve(entry.getName());
                Files.createDirectories(target.getParent());
                try (FileOutputStream fos = new FileOutputStream(target.toFile())) {
                    int n;
                    while ((n = zis.read(buf)) > 0) fos.write(buf, 0, n);
                }
            }
        }
    }

    private void deleteRecursive(Path dir) {
        if (!Files.exists(dir)) return;
        try {
            Files.walkFileTree(dir, new SimpleFileVisitor<>() {
                @Override
                public FileVisitResult visitFile(Path f, BasicFileAttributes a) throws IOException {
                    Files.delete(f);
                    return FileVisitResult.CONTINUE;
                }
                @Override
                public FileVisitResult postVisitDirectory(Path d, IOException e) throws IOException {
                    Files.delete(d);
                    return FileVisitResult.CONTINUE;
                }
            });
        } catch (IOException ignored) {
        }
    }

    private String mavenPath(String name) {
        String[] p = name.split(":");
        return p[0].replace('.', '/') + "/" + p[1] + "/" + p[2] + "/" + p[1] + "-" + p[2] + (p.length > 3 ? "-" + p[3] : "") + ".jar";
    }

    /* ═══════════════════════════════════════════════════════════════
       JSON LIBRARY
       ═══════════════════════════════════════════════════════════════ */
    static class Json {
        static JsonValue parse(String text) {
            return new JsonParser(text).readValue();
        }

        static class JsonParser {
            private final String s;
            private int i;

            JsonParser(String s) {
                this.s = s;
            }

            JsonValue readValue() {
                skipWs();
                char c = peek();
                if (c == '{') return readObject();
                if (c == '[') return readArray();
                if (c == '"') return JsonValue.str(readString());
                if (c == 't') {
                    i += 4;
                    return JsonValue.bool(true);
                }
                if (c == 'f') {
                    i += 5;
                    return JsonValue.bool(false);
                }
                if (c == 'n') {
                    i += 4;
                    return JsonValue.NULL;
                }
                return JsonValue.num(readNumber());
            }

            private JsonObject readObject() {
                JsonObject obj = new JsonObject();
                i++;
                skipWs();
                if (peek() == '}') {
                    i++;
                    return obj;
                }
                while (true) {
                    skipWs();
                    String key = readString();
                    skipWs();
                    i++;
                    obj.members.put(key, readValue());
                    skipWs();
                    char c = peek();
                    if (c == ',') {
                        i++;
                        continue;
                    }
                    if (c == '}') {
                        i++;
                        return obj;
                    }
                }
            }

            private JsonArray readArray() {
                JsonArray arr = new JsonArray();
                i++;
                skipWs();
                if (peek() == ']') {
                    i++;
                    return arr;
                }
                while (true) {
                    arr.values.add(readValue());
                    skipWs();
                    char c = peek();
                    if (c == ',') {
                        i++;
                        continue;
                    }
                    if (c == ']') {
                        i++;
                        return arr;
                    }
                }
            }

            private String readString() {
                if (peek() != '"') throw new RuntimeException("expected string");
                i++;
                StringBuilder b = new StringBuilder();
                while (true) {
                    char c = s.charAt(i++);
                    if (c == '"') return b.toString();
                    if (c == '\\') {
                        char e = s.charAt(i++);
                        switch (e) {
                            case '"': case '\\': case '/': b.append(e); break;
                            case 'n': b.append('\n'); break;
                            case 't': b.append('\t'); break;
                            case 'r': b.append('\r'); break;
                            case 'b': b.append('\b'); break;
                            case 'f': b.append('\f'); break;
                            case 'u': b.append((char) Integer.parseInt(s.substring(i, i + 4), 16)); i += 4; break;
                            default: b.append(e);
                        }
                    } else {
                        b.append(c);
                    }
                }
            }

            private String readNumber() {
                int start = i;
                if (i < s.length() && s.charAt(i) == '-') i++;
                while (i < s.length() && "0123456789.eE+-".indexOf(s.charAt(i)) >= 0) i++;
                return s.substring(start, i);
            }

            private char peek() {
                return i < s.length() ? s.charAt(i) : '\0';
            }

            private void skipWs() {
                while (i < s.length() && Character.isWhitespace(s.charAt(i))) i++;
            }
        }
    }

    static class JsonValue {
        static final JsonValue NULL = new JsonValue(0, null);
        private final int type;
        private final Object value;

        JsonValue(int type, Object v) {
            this.type = type;
            this.value = v;
        }

        static JsonValue str(String s) {
            return new JsonValue(1, s);
        }

        static JsonValue num(String n) {
            return new JsonValue(2, n);
        }

        static JsonValue bool(boolean b) {
            return new JsonValue(3, b);
        }

        JsonObject asObject() {
            return this instanceof JsonObject ? (JsonObject) this : (JsonObject) value;
        }

        JsonArray asArray() {
            return this instanceof JsonArray ? (JsonArray) this : (JsonArray) value;
        }

        String raw() {
            return value == null ? null : String.valueOf(value);
        }

        String toJson() {
            if (this instanceof JsonObject) return toString();
            if (this instanceof JsonArray) return toString();
            if (type == 0) return "null";
            if (type == 1) return escape((String) value);
            if (type == 3) return Boolean.toString((Boolean) value);
            return String.valueOf(value);
        }

        @Override
        public String toString() {
            return type == 1 ? raw() : toJson();
        }

        static String escape(String s) {
            StringBuilder b = new StringBuilder("\"");
            for (int i = 0; i < s.length(); i++) {
                char c = s.charAt(i);
                switch (c) {
                    case '"': b.append("\\\""); break;
                    case '\\': b.append("\\\\"); break;
                    case '\n': b.append("\\n"); break;
                    case '\r': b.append("\\r"); break;
                    case '\t': b.append("\\t"); break;
                    case '\b': b.append("\\b"); break;
                    case '\f': b.append("\\f"); break;
                    default:
                        if (c < 0x20) b.append(String.format("\\u%04x", (int) c));
                        else b.append(c);
                }
            }
            return b.append('"').toString();
        }
    }

    static class JsonObject extends JsonValue {
        final Map<String, JsonValue> members = new LinkedHashMap<>();

        JsonObject() {
            super(0, null);
        }

        boolean has(String k) {
            return members.containsKey(k);
        }

        JsonValue get(String k) {
            return members.get(k);
        }

        String getString(String k) {
            JsonValue v = members.get(k);
            return v == null ? null : v.raw();
        }

        JsonArray getArray(String k) {
            return (JsonArray) members.get(k);
        }

        List<JsonValue> values() {
            return new ArrayList<>(members.values());
        }

        @Override
        public String toJson() {
            StringBuilder b = new StringBuilder("{");
            boolean first = true;
            for (Map.Entry<String, JsonValue> e : members.entrySet()) {
                if (!first) b.append(',');
                first = false;
                b.append(escape(e.getKey())).append(':').append(e.getValue().toJson());
            }
            return b.append('}').toString();
        }

        @Override
        public String toString() {
            return toJson();
        }
    }

    static class JsonArray extends JsonValue {
        final List<JsonValue> values = new ArrayList<>();

        JsonArray() {
            super(0, null);
        }

        boolean isEmpty() {
            return values.isEmpty();
        }

        JsonValue get(int i) {
            return values.get(i);
        }

        int size() {
            return values.size();
        }

        @Override
        public String toJson() {
            StringBuilder b = new StringBuilder("[");
            for (int i = 0; i < values.size(); i++) {
                if (i > 0) b.append(',');
                b.append(values.get(i).toJson());
            }
            return b.append(']').toString();
        }

        @Override
        public String toString() {
            return toJson();
        }
    }
}