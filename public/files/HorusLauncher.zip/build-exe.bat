@echo off
setlocal EnableDelayedExpansion
cd /d %~dp0
chcp 65001 >nul
title HorusLauncher — сборка EXE

echo ============================================
echo   HorusLauncher: сборка EXE для сайта
echo ============================================
echo.

where javac >nul 2>&1
if errorlevel 1 (
  echo [X] javac не найден. Установи JDK 17+ (Adoptium Temurin: https://adoptium.net)
  echo     и убедись, что "javac" доступен в PATH.
  pause & exit /b 1
)
where jpackage >nul 2>&1
if errorlevel 1 (
  echo [X] jpackage не найден. Нужна ПОЛНАЯ установка JDK 14+ (не JRE).
  pause & exit /b 1
)

echo [*] Компиляция исходников...
if not exist dist mkdir dist
javac -encoding UTF-8 -d dist src\com\horus\launcher\HorusLauncher.java
if errorlevel 1 ( echo [X] Ошибка компиляции & pause & exit /b 1 )

echo [*] Создание JAR...
jar cfe dist\HorusLauncher.jar com.horus.launcher.HorusLauncher -C dist .
if errorlevel 1 ( echo [X] Ошибка создания JAR & pause & exit /b 1 )

echo [*] Сборка exe (jpackage)...
if exist out rmdir /s /q out
set ICON=
if exist app\icon.ico set ICON=--icon app\icon.ico
jpackage --type app-image --name HorusLauncher --input dist --main-jar HorusLauncher.jar --main-class com.horus.launcher.HorusLauncher --dest out %ICON%
if errorlevel 1 ( echo [X] Ошибка jpackage & pause & exit /b 1 )

echo [*] Архивация...
if exist HorusLauncher.zip del HorusLauncher.zip
powershell -NoProfile -Command "Compress-Archive -Path 'out\HorusLauncher' -DestinationPath 'HorusLauncher.zip'"

echo.
echo ============================================
echo   ГОТОВО!
echo   EXE:  out\HorusLauncher\HorusLauncher.exe
echo   ZIP:  HorusLauncher.zip  ^<- клади на сайт
echo ============================================
echo.
echo Дальше: скопируй HorusLauncher.zip в
echo   C:\dev\HorusWebsite\public\files\
echo (создай папку files, если её нет), затем:
echo   git add . ^&^& git commit -m "launcher build" ^&^& git push
echo.
pause
